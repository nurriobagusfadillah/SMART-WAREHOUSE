import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useNavigate, useLocation } from 'react-router';
import { 
  Home, 
  Settings, 
  BarChart2, 
  Brain,
  Thermometer,
  Droplets,
  Fan,
  Zap,
  CloudRain,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

// --- DATA SIMULASI ---
const dataHariIni = [
  { time: '10:00', temp: 24, hum: 55 },
  { time: '10:30', temp: 25, hum: 57 },
  { time: '11:00', temp: 27, hum: 60 },
  { time: '11:30', temp: 28, hum: 65 },
  { time: '12:00', temp: 29, hum: 68 },
  { time: '12:30', temp: 28, hum: 64 },
];

const dataMingguIni = [
  { time: 'Senin', temp: 26, hum: 60 },
  { time: 'Selasa', temp: 28, hum: 65 },
  { time: 'Rabu', temp: 25, hum: 58 },
  { time: 'Kamis', temp: 29, hum: 70 },
  { time: 'Jumat', temp: 27, hum: 62 },
  { time: 'Sabtu', temp: 24, hum: 55 },
  { time: 'Minggu', temp: 26, hum: 59 },
];

const dataBulanIni = [
  { time: 'Mg 1', temp: 25, hum: 58 },
  { time: 'Mg 2', temp: 27, hum: 62 },
  { time: 'Mg 3', temp: 28, hum: 66 },
  { time: 'Mg 4', temp: 26, hum: 60 },
];

const dataPrediksi = [
  { time: '13:00', temp: 28, hum: 64 },
  { time: '14:00', temp: 29, hum: 68 },
  { time: '15:00', temp: 31, hum: 76 }, // Melebihi batas
  { time: '16:00', temp: 32, hum: 80 },
];

const logPeristiwa = [
  { time: '12:30', event: 'Kelembapan stabil di 64%', type: 'info' },
  { time: '11:45', event: 'Lonjakan suhu terdeteksi (29°C)', type: 'warning' },
  { time: '11:00', event: 'Kipas otomatis diaktifkan', type: 'system' },
  { time: '10:00', event: 'Sistem ESP32 Aktif', type: 'system' },
];

// --- KOMPONEN DASAR ---

const MobileShell = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="flex justify-center items-center min-h-screen bg-black">
      <div className="w-full max-w-[400px] h-[100dvh] bg-background text-foreground flex flex-col relative overflow-hidden sm:border sm:border-border sm:h-[850px] sm:rounded-3xl shadow-2xl">
        {children}
      </div>
    </div>
  );
};

const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Home, label: 'Beranda' },
    { path: '/analytics', icon: BarChart2, label: 'Analitik' },
    { path: '/controls', icon: Settings, label: 'Kontrol' },
    { path: '/ai', icon: Brain, label: 'AI Cerdas' },
  ];

  return (
    <div className="absolute bottom-0 w-full bg-card border-t border-border px-6 py-4 flex justify-between items-center z-50">
      {navItems.map((item) => {
        const active = location.pathname === item.path;
        const Icon = item.icon;
        return (
          <button 
            key={item.path} 
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-accent-green' : 'text-muted-foreground'}`}
          >
            <Icon size={24} className={active ? 'drop-shadow-[0_0_8px_rgba(0,230,118,0.5)]' : ''} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
};

// --- LAYAR / SCREENS ---

const DashboardScreen = () => {
  const [fanOn, setFanOn] = useState(true);
  const [mode, setMode] = useState<'Auto' | 'Manual'>('Auto');
  
  // Format tanggal Indonesia
  const tanggal = new Date().toLocaleDateString('id-ID', { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-6 pt-12 no-scrollbar">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">Ringkasan</h1>
          <p className="text-sm text-muted-foreground">{tanggal}</p>
        </div>
        <div className="flex items-center gap-2 bg-card px-3 py-1.5 rounded-full border border-border">
          <div className="w-2 h-2 rounded-full bg-accent-green animate-pulse"></div>
          <span className="text-xs font-medium">ESP32 Aktif</span>
        </div>
      </div>

      {/* Kartu Sensor Real-time */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-card rounded-2xl p-5 border border-border flex flex-col relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-accent-red/5 rounded-full -mr-10 -mt-10 blur-xl pointer-events-none"></div>
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Thermometer size={16} className="text-accent-red" />
            <span className="text-sm font-medium">Suhu</span>
          </div>
          <div className="text-4xl font-bold mb-1 flex items-start">
            28<span className="text-xl text-muted-foreground mt-1">°C</span>
          </div>
          <div className="text-xs text-accent-red font-medium">Peringatan: Panas</div>
        </div>
        
        <div className="bg-card rounded-2xl p-5 border border-border flex flex-col relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-accent-green/5 rounded-full -mr-10 -mt-10 blur-xl pointer-events-none"></div>
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Droplets size={16} className="text-accent-green" />
            <span className="text-sm font-medium">Kelembapan</span>
          </div>
          <div className="text-4xl font-bold mb-1 flex items-start">
            65<span className="text-xl text-muted-foreground mt-1">%</span>
          </div>
          <div className="text-xs text-accent-green font-medium">Kondisi Optimal</div>
        </div>
      </div>

      {/* Grafik Mini */}
      <div className="bg-card rounded-2xl p-5 border border-border mb-6">
        <h3 className="text-sm font-medium text-muted-foreground mb-4">Tren Suhu (2 Jam Terakhir)</h3>
        <div className="h-20 w-full -ml-4 overflow-hidden flex justify-center">
          <AreaChart width={320} height={80} data={dataHariIni}>
            <defs>
              <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-accent-red)" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="var(--color-accent-red)" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Area type="monotone" dataKey="temp" stroke="var(--color-accent-red)" fillOpacity={1} fill="url(#colorTemp)" strokeWidth={2} />
          </AreaChart>
        </div>
      </div>

      {/* Kontrol Aktuator */}
      <div className="bg-card rounded-2xl p-1 border border-border flex">
        <button 
          onClick={() => setMode('Auto')}
          className={`flex-1 py-3 text-sm font-medium rounded-xl transition-all ${mode === 'Auto' ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}
        >
          Otomatis
        </button>
        <button 
          onClick={() => setMode('Manual')}
          className={`flex-1 py-3 text-sm font-medium rounded-xl transition-all ${mode === 'Manual' ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}
        >
          Manual
        </button>
      </div>

      <div className="mt-4 bg-card rounded-2xl p-5 border border-border flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${fanOn ? 'bg-accent-green/20 text-accent-green' : 'bg-muted text-muted-foreground'}`}>
            <Fan className={fanOn ? 'animate-spin' : ''} size={24} />
          </div>
          <div>
            <h3 className="font-semibold text-lg">Kipas Pembuang</h3>
            <p className="text-sm text-muted-foreground">Kontrol Daya</p>
          </div>
        </div>
        
        <button 
          disabled={mode === 'Auto'}
          onClick={() => setFanOn(!fanOn)}
          className={`w-14 h-8 rounded-full p-1 transition-colors ${fanOn ? 'bg-accent-green' : 'bg-muted'} ${mode === 'Auto' ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform ${fanOn ? 'translate-x-6' : 'translate-x-0'}`}></div>
        </button>
      </div>
    </div>
  );
};

// Komponen Range Slider Kustom Sederhana
const SliderControl = ({ 
  label, icon: Icon, colorClass, min, max, valMin, valMax, setValMin, setValMax, unit 
}: any) => {
  const rangeKiri = ((valMin - min) / (max - min)) * 100;
  const rangeKanan = ((max - valMax) / (max - min)) * 100;

  return (
    <div className="bg-card rounded-2xl p-5 border border-border mb-6">
      <div className="flex justify-between items-end mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Icon size={16} className={colorClass} />
            <h3 className="font-medium text-sm text-muted-foreground">{label}</h3>
          </div>
          <div className="text-2xl font-bold">
            {valMin}{unit} - {valMax}{unit}
          </div>
        </div>
      </div>
      
      {/* Slider Interaktif Sederhana */}
      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>Minimum: {valMin}{unit}</span>
          </div>
          <input 
            type="range" 
            min={min} 
            max={max} 
            value={valMin} 
            onChange={(e) => {
              const val = Number(e.target.value);
              if (val < valMax) setValMin(val);
            }}
            className="w-full accent-foreground h-1.5 bg-muted rounded-lg appearance-none cursor-pointer"
          />
        </div>
        <div>
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>Maksimum: {valMax}{unit}</span>
          </div>
          <input 
            type="range" 
            min={min} 
            max={max} 
            value={valMax} 
            onChange={(e) => {
              const val = Number(e.target.value);
              if (val > valMin) setValMax(val);
            }}
            className="w-full accent-foreground h-1.5 bg-muted rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};

const ControlsScreen = () => {
  const [minTemp, setMinTemp] = useState(20);
  const [maxTemp, setMaxTemp] = useState(30);
  
  const [minHum, setMinHum] = useState(40);
  const [maxHum, setMaxHum] = useState(70);

  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-6 pt-12 no-scrollbar">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Kontrol Lingkungan</h1>
        <p className="text-sm text-muted-foreground">Atur batas otomatisasi aktuator</p>
      </div>

      <SliderControl 
        label="Batas Suhu"
        icon={Thermometer}
        colorClass="text-accent-red"
        min={0}
        max={50}
        valMin={minTemp}
        valMax={maxTemp}
        setValMin={setMinTemp}
        setValMax={setMaxTemp}
        unit="°C"
      />

      <SliderControl 
        label="Batas Kelembapan"
        icon={Droplets}
        colorClass="text-accent-green"
        min={0}
        max={100}
        valMin={minHum}
        valMax={maxHum}
        setValMin={setMinHum}
        setValMax={setMaxHum}
        unit="%"
      />

      <div className="bg-card rounded-2xl p-5 border border-border mb-8 flex items-center justify-between">
        <div>
          <h3 className="font-semibold mb-1">Batas RPM Kipas</h3>
          <p className="text-xs text-muted-foreground">Kecepatan maks (Otomatis)</p>
        </div>
        <div className="text-xl font-mono font-bold text-accent-green">
          1200<span className="text-xs font-sans text-muted-foreground">rpm</span>
        </div>
      </div>

      <button 
        onClick={handleSave}
        className={`w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
          isSaved ? 'bg-accent-green text-black' : 'bg-foreground text-background active:scale-[0.98]'
        }`}
      >
        {isSaved ? (
          <>
            <CheckCircle2 size={20} />
            Berhasil Disimpan
          </>
        ) : (
          'Simpan & Terapkan'
        )}
      </button>
    </div>
  );
};

const AnalyticsScreen = () => {
  const [rentangWaktu, setRentangWaktu] = useState<'Hari' | 'Minggu' | 'Bulan'>('Hari');
  
  // Pilih data berdasarkan rentang waktu yang aktif
  const getData = () => {
    switch(rentangWaktu) {
      case 'Minggu': return dataMingguIni;
      case 'Bulan': return dataBulanIni;
      default: return dataHariIni;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-6 pt-12 no-scrollbar">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Analisis Data</h1>
        <p className="text-sm text-muted-foreground">Data riwayat sensor gudang</p>
      </div>

      {/* Pemilih Rentang Waktu */}
      <div className="bg-card rounded-2xl p-1 border border-border flex mb-6">
        {(['Hari', 'Minggu', 'Bulan'] as const).map((tab) => (
          <button 
            key={tab}
            onClick={() => setRentangWaktu(tab)}
            className={`flex-1 py-2 text-sm font-medium rounded-xl transition-all ${
              rentangWaktu === tab ? 'bg-muted text-foreground' : 'text-muted-foreground'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Grafik Utama */}
      <div className="bg-card rounded-2xl p-5 border border-border mb-6">
        <div className="flex gap-4 mb-6">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent-red"></div>
            <span className="text-xs text-muted-foreground">Suhu (°C)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent-green"></div>
            <span className="text-xs text-muted-foreground">Kelembapan (%)</span>
          </div>
        </div>
        
        <div className="h-56 w-full -ml-4 overflow-hidden flex justify-center">
          <LineChart width={320} height={224} data={getData()}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
            <XAxis dataKey="time" stroke="var(--color-muted-foreground)" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis yAxisId="kiri" stroke="var(--color-muted-foreground)" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis yAxisId="kanan" orientation="right" stroke="var(--color-muted-foreground)" fontSize={10} tickLine={false} axisLine={false} />
            <Tooltip 
              contentStyle={{ backgroundColor: 'var(--color-card)', borderColor: 'var(--color-border)', borderRadius: '8px' }}
              itemStyle={{ fontSize: '12px' }}
              labelStyle={{ color: 'var(--color-muted-foreground)' }}
            />
            <Line yAxisId="kiri" type="monotone" dataKey="temp" name="Suhu" stroke="var(--color-accent-red)" strokeWidth={3} dot={false} />
            <Line yAxisId="kanan" type="monotone" dataKey="hum" name="Kelembapan" stroke="var(--color-accent-green)" strokeWidth={3} dot={false} />
          </LineChart>
        </div>
      </div>

      {/* Log Data Peristiwa */}
      <div>
        <h3 className="font-semibold mb-4">Log Peristiwa</h3>
        <div className="space-y-3">
          {logPeristiwa.map((log, i) => (
            <div key={i} className="flex gap-4 items-start bg-card p-4 rounded-xl border border-border">
              <div className={`mt-0.5 w-2 h-2 rounded-full shrink-0 ${
                log.type === 'info' ? 'bg-accent-green' : 
                log.type === 'warning' ? 'bg-accent-red' : 'bg-muted-foreground'
              }`}></div>
              <div className="flex-1">
                <p className="text-sm font-medium mb-1">{log.event}</p>
                <p className="text-xs font-mono text-muted-foreground">{log.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const AIScreen = () => {
  return (
    <div className="flex-1 overflow-y-auto pb-24 px-6 pt-12 no-scrollbar">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-full bg-accent-purple/20 flex items-center justify-center border border-accent-purple/30">
          <Zap size={20} className="text-accent-purple" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Kecerdasan AI</h1>
          <p className="text-sm text-muted-foreground">Pemodelan prediktif gudang</p>
        </div>
      </div>

      {/* Widget Cuaca */}
      <div className="bg-card rounded-2xl p-5 border border-border mb-6">
        <div className="flex items-center gap-2 mb-4 text-muted-foreground text-sm font-medium">
          <CloudRain size={16} />
          Data API BMKG
        </div>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-3xl font-bold mb-1">Hujan Lebat</div>
            <div className="text-sm text-accent-purple font-medium">Diperkirakan dalam 2 jam</div>
          </div>
          <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
            <CloudRain size={24} className="text-muted-foreground" />
          </div>
        </div>
      </div>

      {/* Kartu Peringatan */}
      <div className="bg-accent-purple/10 border border-accent-purple/30 rounded-2xl p-5 mb-6 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-accent-purple/20 blur-3xl rounded-full"></div>
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle size={18} className="text-accent-purple" />
          <h3 className="font-semibold text-accent-purple">Peringatan / Prediksi Sistem</h3>
        </div>
        <p className="text-sm leading-relaxed mb-4 text-foreground/90">
          Berdasarkan prakiraan BMKG dan riwayat gudang, kelembapan internal diprediksi akan <strong className="text-accent-red">melebihi batas 75%</strong> dalam 3 jam ke depan.
        </p>
        
        <button className="w-full py-3 bg-accent-purple hover:bg-accent-purple/90 text-black font-bold rounded-xl transition-colors text-sm">
          Aktifkan Kipas Lebih Awal
        </button>
        <div className="text-right mt-3 text-[10px] text-accent-purple/70 font-mono">
          Akurasi Prediksi 85%
        </div>
      </div>

      {/* Grafik Prediksi */}
      <div className="bg-card rounded-2xl p-5 border border-border">
        <h3 className="text-sm font-medium mb-6">Tren ke Depan (Prediksi)</h3>
        
        <div className="h-40 w-full -ml-4 overflow-hidden flex justify-center">
          <LineChart width={320} height={160} data={dataPrediksi}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
            <XAxis dataKey="time" stroke="var(--color-muted-foreground)" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="var(--color-muted-foreground)" fontSize={10} tickLine={false} axisLine={false} domain={[60, 90]} />
            <Tooltip 
              contentStyle={{ backgroundColor: 'var(--color-card)', borderColor: 'var(--color-border)', borderRadius: '8px' }}
              itemStyle={{ fontSize: '12px' }}
              labelStyle={{ color: 'var(--color-muted-foreground)' }}
            />
            <Line type="monotone" dataKey="hum" name="Kelembapan" stroke="var(--color-accent-purple)" strokeWidth={2} strokeDasharray="5 5" dot={{ fill: 'var(--color-accent-purple)', strokeWidth: 0, r: 3 }} />
          </LineChart>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <MobileShell>
        <Routes>
          <Route path="/" element={<DashboardScreen />} />
          <Route path="/analytics" element={<AnalyticsScreen />} />
          <Route path="/controls" element={<ControlsScreen />} />
          <Route path="/ai" element={<AIScreen />} />
        </Routes>
        <Navigation />
      </MobileShell>
    </BrowserRouter>
  );
}
