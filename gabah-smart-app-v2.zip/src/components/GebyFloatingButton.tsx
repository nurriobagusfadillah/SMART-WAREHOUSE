import React from 'react';
import { TouchableOpacity, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Wheat } from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';

export const GebyFloatingButton = () => {
  const router = useRouter();
  const { colors } = useApp();

  return (
    <TouchableOpacity
      onPress={() => router.push('/warehouse/geby')}
      style={[
        styles.button,
        {
          backgroundColor: colors.yellow,
          borderColor: colors.surface,
        },
      ]}
      accessibilityLabel="Buka Geby AI"
      activeOpacity={0.85}
    >
      <View style={[styles.innerCircle, { backgroundColor: colors.cream }]}>
        <Wheat size={22} color="#293751" />
        <View style={[styles.eye, styles.leftEye]} />
        <View style={[styles.eye, styles.rightEye]} />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 14,
    elevation: 8,
    zIndex: 99,
  },
  innerCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  eye: {
    position: 'absolute',
    top: 11,
    width: 3.5,
    height: 3.5,
    borderRadius: 2,
    backgroundColor: '#293751',
  },
  leftEye: {
    left: 11,
  },
  rightEye: {
    right: 11,
  },
});

