import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { ArrowLeft } from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export const DetailHeader = ({
  title,
  subtitle,
}: {
  title: string;
  subtitle: string;
}) => {
  const router = useRouter();
  const { colors } = useApp();

  return (
    <View
      style={[
        styles.header,
        {
          backgroundColor: colors.surface,
          borderBottomColor: colors.line,
        },
      ]}
    >
      <View style={styles.left}>
        <TouchableOpacity
          onPress={() => router.replace('/warehouses')}
          style={[styles.backBtn, { borderColor: colors.line }]}
          accessibilityLabel="Kembali ke Gudang"
        >
          <ArrowLeft size={20} color={colors.ink} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => router.replace('/warehouses')}>
          <Image
            source={require('@/../assets/images/gabah-smart-logo.png')}
            style={styles.logo}
          />
        </TouchableOpacity>

        <View style={styles.titleContainer}>
          <Text style={[styles.title, { color: colors.ink }]}>{title}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedText }]} numberOfLines={1}>
            {subtitle}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 12,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 38,
    height: 38,
    borderRadius: 12,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  subtitle: {
    fontSize: 12,
    marginTop: 2,
    fontFamily: Fonts.calSans,
  },
});

