import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Pressable,
} from 'react-native';
import { Plus, Menu, Settings, Info } from 'lucide-react-native';
import { Brand } from '@/components/Brand';
import { useApp } from '@/hooks/use-app-context';
import { SettingsModal } from '@/components/SettingsModal';
import { AboutModal } from '@/components/AboutModal';
import { AddWarehouseModal } from '@/components/AddWarehouseModal';
import { Fonts } from '@/constants/theme';

export const AppHeader = () => {
  const { colors } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  return (
    <>
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.surface,
            borderBottomColor: colors.line,
          },
        ]}
      >
        <Brand compact />

        <View style={styles.actions}>
          <TouchableOpacity
            onPress={() => setAddOpen(true)}
            style={[styles.iconButton, { borderColor: colors.line }]}
            accessibilityLabel="Tambah Gudang"
          >
            <Plus size={22} color={colors.ink} />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setMenuOpen(!menuOpen)}
            style={[styles.iconButton, { borderColor: colors.line }]}
            accessibilityLabel="Menu"
          >
            <Menu size={22} color={colors.ink} />
          </TouchableOpacity>
        </View>

        {menuOpen && (
          <>
            <Pressable
              style={StyleSheet.absoluteFill}
              onPress={() => setMenuOpen(false)}
            />
            <View
              style={[
                styles.dropdown,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.line,
                },
              ]}
            >
              <TouchableOpacity
                style={styles.dropdownItem}
                onPress={() => {
                  setMenuOpen(false);
                  setSettingsOpen(true);
                }}
              >
                <Settings size={18} color={colors.ink} />
                <Text style={[styles.dropdownText, { color: colors.ink }]}>Pengaturan</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.dropdownItem}
                onPress={() => {
                  setMenuOpen(false);
                  setAboutOpen(true);
                }}
              >
                <Info size={18} color={colors.ink} />
                <Text style={[styles.dropdownText, { color: colors.ink }]}>Tentang Kami</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </View>

      <AddWarehouseModal visible={addOpen} onClose={() => setAddOpen(false)} />
      <SettingsModal visible={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <AboutModal visible={aboutOpen} onClose={() => setAboutOpen(false)} />
    </>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    zIndex: 50,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  iconButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dropdown: {
    position: 'absolute',
    top: 60,
    right: 16,
    width: 180,
    borderRadius: 16,
    borderWidth: 1,
    padding: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
    zIndex: 100,
  },
  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
    gap: 10,
  },
  dropdownText: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
});

