import React from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Pressable,
  Image,
} from 'react-native';
import { X } from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export const AboutModal = ({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) => {
  const { colors } = useApp();

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable
          style={[
            styles.card,
            {
              backgroundColor: colors.surface,
              borderColor: colors.line,
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          <View style={styles.header}>
            <Image
              source={require('@/../assets/images/gabah-smart-logo.png')}
              style={styles.logo}
            />
            <TouchableOpacity
              onPress={onClose}
              style={[styles.closeButton, { borderColor: colors.line }]}
            >
              <X size={20} color={colors.ink} />
            </TouchableOpacity>
          </View>

          <Text style={[styles.title, { color: colors.ink }]}>Gabah Smart</Text>
          <Text style={[styles.description, { color: colors.mutedText }]}>
            Gabah Smart adalah platform pemantauan gudang berbasis IoT yang membantu menjaga kualitas gabah
            melalui sensor ESP32, kontrol lingkungan otomatis, analisis historis, dan pendamping AI bernama Geby.
          </Text>

          <View style={styles.features}>
            {['Pantauan real-time', 'Kontrol otomatis', 'Rekomendasi AI'].map((item) => (
              <View
                key={item}
                style={[styles.featurePill, { backgroundColor: colors.soft }]}
              >
                <Text style={[styles.featureText, { color: colors.ink }]}>{item}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity
            onPress={onClose}
            style={[styles.closeModalButton, { backgroundColor: colors.brand }]}
          >
            <Text style={styles.closeModalText}>Tutup</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(17, 18, 16, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    width: '100%',
    maxWidth: 440,
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 18,
  },
  closeButton: {
    padding: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 8,
    fontFamily: Fonts.calSans,
  },
  description: {
    fontSize: 14,
    lineHeight: 22,
    fontFamily: Fonts.calSans,
  },
  features: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 18,
  },
  featurePill: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
  },
  featureText: {
    fontSize: 12,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  closeModalButton: {
    marginTop: 24,
    width: '100%',
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
  },
  closeModalText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});

