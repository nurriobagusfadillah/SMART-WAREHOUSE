import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { usePathname, useRouter } from 'expo-router';
import { Home, BarChart2, SlidersHorizontal, Sparkles } from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export const DetailNav = () => {
  const pathname = usePathname();
  const router = useRouter();
  const { colors } = useApp();

  const navItems = [
    {
      route: '/warehouse/dashboard',
      label: 'Beranda',
      icon: Home,
      match: ['/warehouse/dashboard', '/warehouse'],
    },
    {
      route: '/warehouse/analytics',
      label: 'Analitik',
      icon: BarChart2,
      match: ['/warehouse/analytics'],
    },
    {
      route: '/warehouse/controls',
      label: 'Kontrol',
      icon: SlidersHorizontal,
      match: ['/warehouse/controls'],
    },
    {
      route: '/warehouse/insights',
      label: 'Wawasan',
      icon: Sparkles,
      match: ['/warehouse/insights'],
    },
  ];

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.nav,
          borderTopColor: colors.line,
        },
      ]}
    >
      <View style={styles.content}>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.match.some((m) => pathname.endsWith(m) || pathname === m);
          const activeColor = colors.brand;
          const inactiveColor = colors.navMuted;

          return (
            <TouchableOpacity
              key={item.route}
              onPress={() => router.push(item.route as any)}
              style={styles.tabButton}
            >
              <Icon size={20} color={isActive ? activeColor : inactiveColor} />
              <Text
                style={[
                  styles.tabLabel,
                  {
                    color: isActive ? activeColor : inactiveColor,
                    fontWeight: isActive ? '700' : '500',
                  },
                ]}
              >
                {item.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderTopWidth: 1,
    paddingTop: 8,
    paddingBottom: Platform.select({ ios: 24, default: 12 }),
    width: '100%',
  },
  content: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    maxWidth: 600,
    width: '100%',
    alignSelf: 'center',
  },
  tabButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
    minWidth: 64,
    gap: 4,
  },
  tabLabel: {
    fontSize: 11,
    fontFamily: Fonts.calSans,
  },
});

