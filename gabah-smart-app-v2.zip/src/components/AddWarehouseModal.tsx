import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Pressable,
} from 'react-native';
import { X } from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export const AddWarehouseModal = ({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) => {
  const { colors, addWarehouse } = useApp();
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleSave = () => {
    if (!name.trim() || code.trim().length < 4) {
      setError('Isi nama gudang dan kode pairing minimal 4 karakter.');
      return;
    }
    addWarehouse(name.trim(), code.trim().toUpperCase());
    setName('');
    setCode('');
    setError('');
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable
          style={[
            styles.card,
            {
              backgroundColor: colors.surface,
              borderColor: colors.line,
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          <View style={styles.header}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.title, { color: colors.ink }]}>Hubungkan gudang</Text>
              <Text style={[styles.subtitle, { color: colors.mutedText }]}>
                Masukkan detail yang tampil pada perangkat ESP32.
              </Text>
            </View>
            <TouchableOpacity
              onPress={onClose}
              style={[styles.closeButton, { borderColor: colors.line }]}
            >
              <X size={20} color={colors.ink} />
            </TouchableOpacity>
          </View>

          <Text style={[styles.label, { color: colors.ink }]}>Nama gudang</Text>
          <TextInput
            value={name}
            onChangeText={(text) => {
              setName(text);
              if (error) setError('');
            }}
            placeholder="Contoh: Gudang Utama"
            placeholderTextColor={colors.mutedText}
            style={[
              styles.input,
              {
                backgroundColor: colors.soft,
                borderColor: colors.line,
                color: colors.ink,
              },
            ]}
          />

          <Text style={[styles.label, { color: colors.ink, marginTop: 14 }]}>
            Kode pairing ESP32
          </Text>
          <TextInput
            value={code}
            onChangeText={(text) => {
              setCode(text);
              if (error) setError('');
            }}
            placeholder="Contoh: ESP32-A7K9"
            placeholderTextColor={colors.mutedText}
            autoCapitalize="characters"
            style={[
              styles.input,
              {
                backgroundColor: colors.soft,
                borderColor: colors.line,
                color: colors.ink,
              },
            ]}
          />

          {error ? <Text style={[styles.error, { color: colors.danger }]}>{error}</Text> : null}

          <TouchableOpacity
            onPress={handleSave}
            style={[styles.submitButton, { backgroundColor: colors.brand }]}
          >
            <Text style={styles.submitText}>Hubungkan Perangkat</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(17, 18, 16, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    width: '100%',
    maxWidth: 440,
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  subtitle: {
    fontSize: 13,
    marginTop: 4,
    fontFamily: Fonts.calSans,
  },
  closeButton: {
    padding: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
    fontFamily: Fonts.calSans,
  },
  input: {
    width: '100%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    fontSize: 15,
    fontFamily: Fonts.calSans,
  },
  error: {
    fontSize: 13,
    marginTop: 10,
    fontFamily: Fonts.calSans,
  },
  submitButton: {
    marginTop: 22,
    width: '100%',
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
  },
  submitText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});

