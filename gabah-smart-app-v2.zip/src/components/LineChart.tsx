import React, { useState } from 'react';
import { View, Text, StyleSheet, useWindowDimensions, Platform } from 'react-native';
import Svg, { Line, Path, Text as SvgText, Circle, G, Rect } from 'react-native-svg';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export interface DataPoint {
  time: string;
  temp?: number;
  hum?: number;
}

interface SvgChartProps {
  data: DataPoint[];
  height?: number;
  isPrediction?: boolean;
}

export const SvgChart = ({
  data,
  height = 250,
  isPrediction = false,
}: SvgChartProps) => {
  const { width: windowWidth } = useWindowDimensions();
  const { theme, colors } = useApp();
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const chartWidth = Math.min(windowWidth - 40, 720);
  const paddingLeft = 40;
  const paddingRight = 24;
  const paddingTop = 28;
  const paddingBottom = 34;

  const innerWidth = chartWidth - paddingLeft - paddingRight;
  const innerHeight = height - paddingTop - paddingBottom;

  if (!data || data.length === 0) return null;

  // Determine min/max values
  let minY = 0;
  let maxY = 100;

  if (isPrediction) {
    minY = 50;
    maxY = 90;
  } else {
    minY = 15;
    maxY = 80;
  }

  const getYCoord = (val: number) => {
    const clamped = Math.max(minY, Math.min(maxY, val));
    return paddingTop + innerHeight - ((clamped - minY) / (maxY - minY)) * innerHeight;
  };

  const getXCoord = (index: number) => {
    if (data.length <= 1) return paddingLeft + innerWidth / 2;
    return paddingLeft + (index / (data.length - 1)) * innerWidth;
  };

  // Generate paths
  let tempPath = '';
  let humPath = '';

  data.forEach((d, idx) => {
    const x = getXCoord(idx);
    if (d.temp !== undefined) {
      const y = getYCoord(d.temp);
      tempPath += `${idx === 0 ? 'M' : 'L'} ${x} ${y} `;
    }
    if (d.hum !== undefined) {
      const y = getYCoord(d.hum);
      humPath += `${idx === 0 ? 'M' : 'L'} ${x} ${y} `;
    }
  });

  const yTicks = isPrediction ? [60, 70, 80, 90] : [20, 40, 60, 80];

  // Active hovered point details
  const activeData = hoveredIndex !== null ? data[hoveredIndex] : null;
  const activeX = hoveredIndex !== null ? getXCoord(hoveredIndex) : 0;

  // Tooltip dimensions & calculations
  const tooltipWidth = isPrediction ? 130 : 144;
  const tooltipHeight = activeData && activeData.temp !== undefined && activeData.hum !== undefined ? 64 : 46;

  let tooltipX = activeX - tooltipWidth / 2;
  if (tooltipX < paddingLeft - 10) {
    tooltipX = paddingLeft - 10;
  } else if (tooltipX + tooltipWidth > chartWidth - paddingRight + 10) {
    tooltipX = chartWidth - paddingRight - tooltipWidth + 10;
  }

  let tooltipY = paddingTop;
  if (activeData) {
    const highestVal = Math.max(activeData.temp ?? 0, activeData.hum ?? 0);
    const pointY = getYCoord(highestVal);
    if (pointY - tooltipHeight - 12 < 10) {
      tooltipY = pointY + 14; // Render below if too close to top
    } else {
      tooltipY = pointY - tooltipHeight - 12; // Render above
    }
  }

  const columnWidth = innerWidth / (data.length > 1 ? data.length - 1 : 1);

  return (
    <View style={styles.container}>
      {/* Active hover info pill */}
      {activeData ? (
        <View
          style={[
            styles.activeBanner,
            {
              backgroundColor: theme === 'dark' ? '#222428' : 'rgba(0,0,0,0.2)',
              borderColor: colors.line,
            },
          ]}
        >
          <Text style={[styles.bannerTime, { color: colors.cardText }]}>
            🕒 {activeData.time}
          </Text>
          {activeData.temp !== undefined && (
            <Text style={[styles.bannerTemp, { color: colors.yellow }]}>
              • Suhu: {activeData.temp}°C
            </Text>
          )}
          {activeData.hum !== undefined && (
            <Text style={[styles.bannerHum, { color: colors.brand }]}>
              • {isPrediction ? 'Prediksi: ' : 'Kelembapan: '}
              {activeData.hum}%
            </Text>
          )}
        </View>
      ) : (
        <View style={styles.hintBanner}>
          <Text style={[styles.hintText, { color: colors.cardMuted }]}>
            {Platform.OS === 'web'
              ? '💡 Arahkan kursor ke titik diagram untuk melihat detail data'
              : '💡 Sentuh titik diagram untuk melihat detail data'}
          </Text>
        </View>
      )}

      <Svg
        width={chartWidth}
        height={height}
        {...({
          onPointerLeave: () => setHoveredIndex(null),
        } as any)}
      >
        {/* Horizontal grid lines & Y-axis labels */}
        {yTicks.map((val) => {
          const y = getYCoord(val);
          return (
            <G key={`tick-${val}`}>
              <Line
                x1={paddingLeft}
                y1={y}
                x2={chartWidth - paddingRight}
                y2={y}
                stroke={theme === 'dark' ? 'rgba(255, 255, 255, 0.08)' : 'rgba(255, 255, 255, 0.12)'}
                strokeDasharray="4 4"
                strokeWidth={1}
              />
              <SvgText
                x={paddingLeft - 10}
                y={y + 4}
                fontSize={11}
                fontWeight="600"
                fill={theme === 'dark' ? '#9ca3af' : '#b9c0cb'}
                textAnchor="end"
              >
                {val}
              </SvgText>
            </G>
          );
        })}

        {/* X-axis labels */}
        {data.map((d, idx) => {
          const x = getXCoord(idx);
          const isSelected = hoveredIndex === idx;
          return (
            <SvgText
              key={`x-${d.time}-${idx}`}
              x={x}
              y={height - 10}
              fontSize={11}
              fontWeight={isSelected ? '700' : '500'}
              fill={isSelected ? (theme === 'dark' ? '#ffffff' : '#ffffff') : (theme === 'dark' ? '#9ca3af' : '#b9c0cb')}
              textAnchor="middle"
            >
              {d.time}
            </SvgText>
          );
        })}

        {/* Temperature Line */}
        {tempPath ? (
          <Path
            d={tempPath}
            fill="none"
            stroke="#EEB742"
            strokeWidth={3}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ) : null}

        {/* Humidity Line */}
        {humPath ? (
          <Path
            d={humPath}
            fill="none"
            stroke="#3DB45A"
            strokeWidth={3}
            strokeDasharray={isPrediction ? '6 6' : undefined}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ) : null}

        {/* Vertical hover indicator line */}
        {hoveredIndex !== null && (
          <Line
            x1={activeX}
            y1={paddingTop}
            x2={activeX}
            y2={height - paddingBottom}
            stroke="rgba(255, 255, 255, 0.4)"
            strokeDasharray="3 3"
            strokeWidth={1.5}
          />
        )}

        {/* Normal data dots */}
        {data.map((d, idx) => {
          const x = getXCoord(idx);
          const isSelected = hoveredIndex === idx;
          return (
            <G key={`dots-${idx}`}>
              {d.temp !== undefined && (
                <>
                  {isSelected && (
                    <Circle
                      cx={x}
                      cy={getYCoord(d.temp)}
                      r={9}
                      fill="rgba(238, 183, 66, 0.35)"
                    />
                  )}
                  <Circle
                    cx={x}
                    cy={getYCoord(d.temp)}
                    r={isSelected ? 6 : 4}
                    stroke={isSelected ? '#ffffff' : 'none'}
                    strokeWidth={isSelected ? 2 : 0}
                    fill="#EEB742"
                  />
                </>
              )}
              {d.hum !== undefined && (
                <>
                  {isSelected && (
                    <Circle
                      cx={x}
                      cy={getYCoord(d.hum)}
                      r={9}
                      fill="rgba(61, 180, 90, 0.35)"
                    />
                  )}
                  <Circle
                    cx={x}
                    cy={getYCoord(d.hum)}
                    r={isSelected ? 6 : 4}
                    stroke={isSelected ? '#ffffff' : 'none'}
                    strokeWidth={isSelected ? 2 : 0}
                    fill="#3DB45A"
                  />
                </>
              )}
            </G>
          );
        })}

        {/* Tooltip Card inside SVG for crisp pixel-perfect render */}
        {activeData && (
          <G key="tooltip-group">
            <Rect
              x={tooltipX}
              y={tooltipY}
              width={tooltipWidth}
              height={tooltipHeight}
              rx={10}
              ry={10}
              fill={theme === 'dark' ? '#111210' : '#1e2023'}
              stroke={theme === 'dark' ? '#374151' : 'rgba(255, 255, 255, 0.25)'}
              strokeWidth={1.5}
            />
            <SvgText
              x={tooltipX + 10}
              y={tooltipY + 16}
              fontSize={11}
              fontWeight="700"
              fill="#ffffff"
            >
              🕒 {activeData.time}
            </SvgText>
            {activeData.temp !== undefined && (
              <SvgText
                x={tooltipX + 10}
                y={tooltipY + 34}
                fontSize={12}
                fontWeight="600"
                fill="#EEB742"
              >
                Suhu: {activeData.temp}°C
              </SvgText>
            )}
            {activeData.hum !== undefined && (
              <SvgText
                x={tooltipX + 10}
                y={activeData.temp !== undefined ? tooltipY + 52 : tooltipY + 34}
                fontSize={12}
                fontWeight="600"
                fill="#3DB45A"
              >
                {isPrediction ? 'Prediksi: ' : 'Kelembapan: '}
                {activeData.hum}%
              </SvgText>
            )}
          </G>
        )}

        {/* Transparent Hit-Areas for Hover / Pointer Events */}
        {data.map((_, idx) => {
          const x = getXCoord(idx);
          const hitWidth = Math.max(columnWidth, 44);
          return (
            <Rect
              key={`hit-${idx}`}
              x={x - hitWidth / 2}
              y={0}
              width={hitWidth}
              height={height}
              fill="transparent"
              onPress={() => setHoveredIndex(hoveredIndex === idx ? null : idx)}
              {...({
                style: { cursor: 'pointer' },
                onPointerEnter: () => setHoveredIndex(idx),
                onPointerMove: () => setHoveredIndex(idx),
                onPointerDown: () => setHoveredIndex(idx),
              } as any)}
            />
          );
        })}
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 6,
    width: '100%',
  },
  activeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 8,
  },
  bannerTime: {
    fontSize: 12,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  bannerTemp: {
    fontSize: 12,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  bannerHum: {
    fontSize: 12,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  hintBanner: {
    paddingVertical: 4,
    marginBottom: 6,
  },
  hintText: {
    fontSize: 11,
    fontFamily: Fonts.calSans,
  },
});
