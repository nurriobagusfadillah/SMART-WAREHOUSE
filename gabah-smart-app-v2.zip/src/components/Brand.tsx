import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export const Brand = ({ compact = false }: { compact?: boolean }) => {
  const { colors } = useApp();

  return (
    <View style={styles.container}>
      <Image
        source={require('@/../assets/images/gabah-smart-logo.png')}
        style={[styles.logo, compact ? styles.logoCompact : styles.logoRegular]}
        resizeMode="contain"
      />
      <View>
        <Text style={[styles.title, compact ? styles.titleCompact : styles.titleRegular, { color: colors.ink }]}>
          Gabah <Text style={{ color: colors.brand }}>Smart</Text>
        </Text>
        {!compact && (
          <Text style={[styles.subtitle, { color: colors.mutedText }]}>
            Sistem gudang cerdas
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  logo: {
    borderRadius: 14,
  },
  logoCompact: {
    width: 36,
    height: 36,
  },
  logoRegular: {
    width: 44,
    height: 44,
  },
  title: {
    fontFamily: Fonts.calSans,
    fontWeight: '700',
    lineHeight: 28,
  },
  titleCompact: {
    fontSize: 20,
    lineHeight: 22,
  },
  titleRegular: {
    fontSize: 24,
    lineHeight: 26,
  },
  subtitle: {
    fontSize: 12,
    marginTop: 2,
    fontFamily: Fonts.calSans,
  },
});

