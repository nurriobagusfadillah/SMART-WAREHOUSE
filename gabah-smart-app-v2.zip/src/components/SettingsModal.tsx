import React from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Pressable,
} from 'react-native';
import { Sun, Moon, CheckCircle2, X } from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export const SettingsModal = ({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) => {
  const { theme, setTheme, colors } = useApp();

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable
          style={[
            styles.card,
            {
              backgroundColor: colors.surface,
              borderColor: colors.line,
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          <View style={styles.header}>
            <View>
              <Text style={[styles.title, { color: colors.ink }]}>Pengaturan</Text>
              <Text style={[styles.subtitle, { color: colors.mutedText }]}>
                Sesuaikan tema tampilan Gabah Smart
              </Text>
            </View>
            <TouchableOpacity
              onPress={onClose}
              style={[styles.closeButton, { borderColor: colors.line }]}
            >
              <X size={20} color={colors.ink} />
            </TouchableOpacity>
          </View>

          <View style={styles.options}>
            <TouchableOpacity
              onPress={() => setTheme('light')}
              style={[
                styles.choice,
                {
                  borderColor: theme === 'light' ? colors.brand : colors.line,
                  backgroundColor:
                    theme === 'light' ? 'rgba(61, 180, 90, 0.1)' : colors.soft,
                },
              ]}
            >
              <Sun size={24} color={colors.ink} />
              <View style={styles.choiceText}>
                <Text style={[styles.choiceTitle, { color: colors.ink }]}>Terang</Text>
                <Text style={[styles.choiceDesc, { color: colors.mutedText }]}>
                  Hangat dan bersih
                </Text>
              </View>
              {theme === 'light' && <CheckCircle2 size={20} color={colors.brand} />}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setTheme('dark')}
              style={[
                styles.choice,
                {
                  borderColor: theme === 'dark' ? colors.brand : colors.line,
                  backgroundColor:
                    theme === 'dark' ? 'rgba(61, 180, 90, 0.1)' : colors.soft,
                },
              ]}
            >
              <Moon size={24} color={colors.ink} />
              <View style={styles.choiceText}>
                <Text style={[styles.choiceTitle, { color: colors.ink }]}>Gelap</Text>
                <Text style={[styles.choiceDesc, { color: colors.mutedText }]}>
                  Nyaman di malam hari
                </Text>
              </View>
              {theme === 'dark' && <CheckCircle2 size={20} color={colors.brand} />}
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            onPress={onClose}
            style={[styles.doneButton, { backgroundColor: colors.brand }]}
          >
            <Text style={styles.doneText}>Selesai</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(17, 18, 16, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    width: '100%',
    maxWidth: 440,
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  subtitle: {
    fontSize: 13,
    marginTop: 3,
    fontFamily: Fonts.calSans,
  },
  closeButton: {
    padding: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  options: {
    gap: 12,
  },
  choice: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderRadius: 16,
    padding: 16,
    gap: 14,
  },
  choiceText: {
    flex: 1,
  },
  choiceTitle: {
    fontSize: 16,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  choiceDesc: {
    fontSize: 12,
    marginTop: 2,
    fontFamily: Fonts.calSans,
  },
  doneButton: {
    marginTop: 24,
    width: '100%',
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
  },
  doneText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});

