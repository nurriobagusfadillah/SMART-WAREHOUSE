import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { useWarehouseSensor } from '@/hooks/use-warehouse-sensor';
import { ColorTheme, Fonts } from '@/constants/theme';

type Props = {
  pairingCode: string;
  colors: ColorTheme;
};

/**
 * Sub-komponen kecil untuk menampilkan data sensor live per gudang di daftar warehouses.
 * Dibuat terpisah agar setiap kartu punya hook Firebase sendiri.
 */
export function WarehouseSensorStats({ pairingCode, colors }: Props) {
  const sensor = useWarehouseSensor(pairingCode);

  const tempText = sensor.loading
    ? '…'
    : sensor.temperature !== null
    ? `${sensor.temperature.toFixed(1)}°C`
    : '—';

  const humText = sensor.loading
    ? '…'
    : sensor.humidity !== null
    ? `${sensor.humidity.toFixed(0)}%`
    : '—';

  return (
    <>
      <Text style={[styles.statItem, { color: colors.cardMuted }]}>
        Suhu{' '}
        <Text style={[styles.statValue, { color: colors.cardText }]}>{tempText}</Text>
      </Text>
      <Text style={[styles.statItem, { color: colors.cardMuted }]}>
        Kelembapan{' '}
        <Text style={[styles.statValue, { color: colors.cardText }]}>{humText}</Text>
      </Text>
    </>
  );
}

const styles = StyleSheet.create({
  statItem: {
    fontSize: 13,
    fontFamily: Fonts.calSans,
  },
  statValue: {
    fontWeight: '700',
  },
});

