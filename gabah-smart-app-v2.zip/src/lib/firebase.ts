import { initializeApp, getApps } from 'firebase/app';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: 'AIzaSyDS-JadntOC6jRVUCegrshnFs5e_QuHr00',
  authDomain: 'gabah-smart.firebaseapp.com',
  databaseURL: 'https://gabah-smart-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'gabah-smart',
  storageBucket: 'gabah-smart.firebasestorage.app',
  messagingSenderId: '276936374127',
  appId: '1:276936374127:web:7c9581d61b9b1f1a6f1a9a',
  measurementId: 'G-HF46G13XN4',
};

// Avoid re-initializing on hot reload
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
const database = getDatabase(app);

export { app, database };

