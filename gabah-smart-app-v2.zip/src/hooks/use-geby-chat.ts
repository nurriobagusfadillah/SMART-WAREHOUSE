import { useState, useCallback, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { groq, GROQ_MODEL, GEBY_SYSTEM_PROMPT } from '@/lib/groq';

export type ChatMessage = {
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
};

export type Conversation = {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
};

const STORAGE_KEY = 'geby-conversations';
const MAX_CONVERSATIONS = 50;

function generateId() {
  return `conv-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function titleFromMessage(text: string): string {
  // Ambil 40 karakter pertama sebagai judul otomatis
  const clean = text.replace(/\n/g, ' ').trim();
  return clean.length > 40 ? clean.slice(0, 40) + '…' : clean;
}

async function loadAllConversations(): Promise<Conversation[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function saveAllConversations(convs: Conversation[]) {
  try {
    // Simpan max 50 percakapan, urutkan dari yang terbaru
    const sorted = [...convs].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, MAX_CONVERSATIONS);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(sorted));
  } catch {
    // ignore storage errors
  }
}

export function useGebyChat(warehouseContext?: string) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const [isHistoryLoaded, setIsHistoryLoaded] = useState(false);
  const abortRef = useRef<boolean>(false);

  // Lazy load riwayat saat pertama kali diperlukan
  const loadHistory = useCallback(async () => {
    if (isHistoryLoaded) return;
    setIsLoading(true);
    const convs = await loadAllConversations();
    setConversations(convs);
    setIsHistoryLoaded(true);
    setIsLoading(false);
  }, [isHistoryLoaded]);

  const activeConversation = conversations.find((c) => c.id === activeConvId) ?? null;
  const messages = activeConversation?.messages ?? [];

  // Mulai percakapan baru
  const newConversation = useCallback(() => {
    setActiveConvId(null);
    setStreamingText('');
  }, []);

  // Pilih percakapan dari riwayat
  const selectConversation = useCallback((id: string) => {
    setActiveConvId(id);
    setStreamingText('');
  }, []);

  // Hapus percakapan
  const deleteConversation = useCallback(
    async (id: string) => {
      const updated = conversations.filter((c) => c.id !== id);
      setConversations(updated);
      await saveAllConversations(updated);
      if (activeConvId === id) {
        setActiveConvId(null);
      }
    },
    [conversations, activeConvId]
  );

  // Kirim pesan ke Groq
  const sendMessage = useCallback(
    async (userText: string) => {
      if (!userText.trim() || isStreaming) return;

      abortRef.current = false;
      setStreamingText('');

      const userMsg: ChatMessage = {
        role: 'user',
        text: userText.trim(),
        timestamp: Date.now(),
      };

      // Buat atau lanjutkan percakapan
      let currentConv: Conversation;
      let isNew = false;

      if (activeConvId) {
        const existing = conversations.find((c) => c.id === activeConvId);
        if (existing) {
          currentConv = {
            ...existing,
            messages: [...existing.messages, userMsg],
            updatedAt: Date.now(),
          };
        } else {
          isNew = true;
          currentConv = {
            id: activeConvId,
            title: titleFromMessage(userText),
            messages: [userMsg],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
        }
      } else {
        isNew = true;
        const newId = generateId();
        currentConv = {
          id: newId,
          title: titleFromMessage(userText),
          messages: [userMsg],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        setActiveConvId(newId);
      }

      // Update state langsung biar UI responsif
      setConversations((prev) => {
        const without = prev.filter((c) => c.id !== currentConv.id);
        return [currentConv, ...without];
      });

      setIsStreaming(true);

      // Bangun history untuk Groq API
      const contextNote = warehouseContext
        ? `\n\n[Konteks gudang aktif: ${warehouseContext}]`
        : '';

      const groqMessages = [
        { role: 'system' as const, content: GEBY_SYSTEM_PROMPT + contextNote },
        ...currentConv.messages.map((m) => ({
          role: m.role as 'user' | 'assistant',
          content: m.text,
        })),
      ];

      let fullResponse = '';

      try {
        const stream = await groq.chat.completions.create({
          model: GROQ_MODEL,
          messages: groqMessages,
          temperature: 0.7,
          max_tokens: 1024,
          stream: true,
        });

        for await (const chunk of stream) {
          if (abortRef.current) break;
          const delta = chunk.choices[0]?.delta?.content ?? '';
          fullResponse += delta;
          setStreamingText(fullResponse);
        }
      } catch (err: any) {
        if (!abortRef.current) {
          fullResponse =
            'Aduh, Geby lagi gangguan sinyal nih 😅 Coba lagi sebentar ya, Pak/Bu!';
          if (err?.status === 401) {
            fullResponse =
              '🔑 API key Groq belum diisi atau tidak valid. Minta pemilik aplikasi untuk mengisi API key di src/lib/groq.ts';
          } else if (err?.status === 429) {
            fullResponse =
              '⏳ Geby lagi kelelahan karena terlalu banyak permintaan. Tunggu sebentar ya, terus coba lagi!';
          }
        }
      }

      if (!abortRef.current && fullResponse) {
        const assistantMsg: ChatMessage = {
          role: 'assistant',
          text: fullResponse,
          timestamp: Date.now(),
        };

        const finalConv: Conversation = {
          ...currentConv,
          messages: [...currentConv.messages, assistantMsg],
          updatedAt: Date.now(),
        };

        setConversations((prev) => {
          const without = prev.filter((c) => c.id !== finalConv.id);
          const updated = [finalConv, ...without];
          saveAllConversations(updated); // fire-and-forget
          return updated;
        });
      }

      setStreamingText('');
      setIsStreaming(false);
    },
    [activeConvId, conversations, isStreaming, warehouseContext]
  );

  const stopStreaming = useCallback(() => {
    abortRef.current = true;
    setIsStreaming(false);
    setStreamingText('');
  }, []);

  return {
    conversations,
    activeConversation,
    messages,
    activeConvId,
    isLoading,
    isStreaming,
    streamingText,
    loadHistory,
    newConversation,
    selectConversation,
    deleteConversation,
    sendMessage,
    stopStreaming,
  };
}

