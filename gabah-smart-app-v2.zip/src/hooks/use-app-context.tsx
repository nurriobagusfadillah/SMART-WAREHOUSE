import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Colors, Theme, ColorTheme } from '@/constants/theme';

export type WarehouseItem = {
  id: string;
  name: string;
  pairingCode: string;
  connected: boolean;
};

export type AppContextType = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  colors: ColorTheme;
  warehouses: WarehouseItem[];
  addWarehouse: (name: string, pairingCode: string) => void;
  removeWarehouse: (id: string) => void;
  selectedWarehouseId: string;
  setSelectedWarehouseId: (id: string) => void;
  isOnboarded: boolean;
  setIsOnboarded: (val: boolean) => void;
  isReady: boolean;
};

const AppContext = createContext<AppContextType | null>(null);

const STORAGE_KEYS = {
  THEME: 'gabah-theme',
  WAREHOUSES: 'gabah-warehouses',
  ONBOARDED: 'gabah-onboarded',
  SELECTED_WAREHOUSE: 'gabah-selected-warehouse',
};

const DEFAULT_WAREHOUSES: WarehouseItem[] = [
  { id: '1', name: 'Gudang Utama Kendal', pairingCode: 'ESP32-A7K9', connected: true },
];

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setThemeState] = useState<Theme>('light');
  const [warehouses, setWarehouses] = useState<WarehouseItem[]>(DEFAULT_WAREHOUSES);
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('1');
  const [isOnboarded, setIsOnboardedState] = useState<boolean>(false);
  const [isReady, setIsReady] = useState<boolean>(false);

  useEffect(() => {
    const loadStoredData = async () => {
      try {
        const [savedTheme, savedWarehouses, savedOnboarded, savedSelected] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEYS.THEME),
          AsyncStorage.getItem(STORAGE_KEYS.WAREHOUSES),
          AsyncStorage.getItem(STORAGE_KEYS.ONBOARDED),
          AsyncStorage.getItem(STORAGE_KEYS.SELECTED_WAREHOUSE),
        ]);

        if (savedTheme === 'light' || savedTheme === 'dark') {
          setThemeState(savedTheme);
        }
        if (savedWarehouses) {
          const parsed = JSON.parse(savedWarehouses);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setWarehouses(parsed);
          }
        }
        if (savedOnboarded === 'true') {
          setIsOnboardedState(true);
        }
        if (savedSelected) {
          setSelectedWarehouseId(savedSelected);
        }
      } catch (err) {
        console.warn('Error loading storage data', err);
      } finally {
        setIsReady(true);
      }
    };

    loadStoredData();
  }, []);

  const setTheme = (val: Theme) => {
    setThemeState(val);
    AsyncStorage.setItem(STORAGE_KEYS.THEME, val).catch(() => {});
  };

  const setIsOnboarded = (val: boolean) => {
    setIsOnboardedState(val);
    AsyncStorage.setItem(STORAGE_KEYS.ONBOARDED, val ? 'true' : 'false').catch(() => {});
  };

  const addWarehouse = (name: string, pairingCode: string) => {
    const newId = Date.now().toString();
    const updated = [
      ...warehouses,
      { id: newId, name, pairingCode, connected: true },
    ];
    setWarehouses(updated);
    setSelectedWarehouseId(newId);
    AsyncStorage.setItem(STORAGE_KEYS.WAREHOUSES, JSON.stringify(updated)).catch(() => {});
  };

  const removeWarehouse = (id: string) => {
    const updated = warehouses.filter((item) => item.id !== id);
    setWarehouses(updated);
    if (selectedWarehouseId === id && updated.length > 0) {
      setSelectedWarehouseId(updated[0].id);
    }
    AsyncStorage.setItem(STORAGE_KEYS.WAREHOUSES, JSON.stringify(updated)).catch(() => {});
  };

  const selectWarehouse = (id: string) => {
    setSelectedWarehouseId(id);
    AsyncStorage.setItem(STORAGE_KEYS.SELECTED_WAREHOUSE, id).catch(() => {});
  };

  const colors = Colors[theme];

  return (
    <AppContext.Provider
      value={{
        theme,
        setTheme,
        colors,
        warehouses,
        addWarehouse,
        removeWarehouse,
        selectedWarehouseId,
        setSelectedWarehouseId: selectWarehouse,
        isOnboarded,
        setIsOnboarded,
        isReady,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return ctx;
};
