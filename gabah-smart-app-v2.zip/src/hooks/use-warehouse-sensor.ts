import { useEffect, useRef, useState } from 'react';
import { ref, onValue, set, off, DatabaseReference } from 'firebase/database';
import { database } from '@/lib/firebase';

export type SensorLog = {
  text: string;
  time: string;
  isAlert: boolean;
};

export type SensorReading = {
  temperature: number | null;
  humidity: number | null;
  fanOn: boolean;
  mode: 'auto' | 'manual';
  logs: SensorLog[];
  connected: boolean;
  loading: boolean;
};

const DEFAULT_STATE: SensorReading = {
  temperature: null,
  humidity: null,
  fanOn: false,
  mode: 'auto',
  logs: [],
  connected: false,
  loading: true,
};

/**
 * Hook untuk subscribe ke data sensor real-time dari Firebase RTDB.
 * Data diambil dari path: /warehouses/{pairingCode}/
 *
 * Struktur data ESP32 yang diharapkan:
 * {
 *   temperature: 28.5,
 *   humidity: 65.2,
 *   fanOn: true,
 *   mode: "auto",
 *   logs: [{ text: "...", time: "12:30", isAlert: false }, ...]
 * }
 */
export function useWarehouseSensor(pairingCode: string | undefined) {
  const [data, setData] = useState<SensorReading>(DEFAULT_STATE);
  const listenerRef = useRef<DatabaseReference | null>(null);

  useEffect(() => {
    if (!pairingCode) {
      setData({ ...DEFAULT_STATE, loading: false });
      return;
    }

    const warehouseRef = ref(database, `warehouses/${pairingCode}`);
    listenerRef.current = warehouseRef;

    setData((prev) => ({ ...prev, loading: true }));

    const unsubscribe = onValue(
      warehouseRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const val = snapshot.val();
          const rawLogs = val.logs ?? {};
          // Firebase menyimpan array sebagai object — ubah ke array
          const logsArray: SensorLog[] = Array.isArray(rawLogs)
            ? rawLogs
            : Object.values(rawLogs as Record<string, SensorLog>);

          setData({
            temperature: val.temperature ?? null,
            humidity: val.humidity ?? null,
            fanOn: val.fanOn ?? false,
            mode: val.mode === 'manual' ? 'manual' : 'auto',
            logs: logsArray.slice(-20).reverse(), // tampilkan 20 log terbaru
            connected: true,
            loading: false,
          });
        } else {
          // Node belum ada di RTDB — perangkat belum pernah kirim data
          setData({
            ...DEFAULT_STATE,
            connected: false,
            loading: false,
          });
        }
      },
      (error) => {
        console.warn('[Firebase] Error membaca sensor:', error.message);
        setData((prev) => ({ ...prev, connected: false, loading: false }));
      }
    );

    return () => {
      off(warehouseRef, 'value', unsubscribe);
    };
  }, [pairingCode]);

  /**
   * Tulis perintah kontrol ke Firebase (dari layar Controls / Dashboard).
   * ESP32 mendengarkan path ini dan merespons.
   */
  const setFanOn = async (value: boolean) => {
    if (!pairingCode) return;
    await set(ref(database, `warehouses/${pairingCode}/fanOn`), value);
  };

  const setMode = async (value: 'auto' | 'manual') => {
    if (!pairingCode) return;
    await set(ref(database, `warehouses/${pairingCode}/mode`), value);
  };

  const setThresholds = async (tempThreshold: number, humidityThreshold: number) => {
    if (!pairingCode) return;
    await set(ref(database, `warehouses/${pairingCode}/thresholds`), {
      temperature: tempThreshold,
      humidity: humidityThreshold,
    });
  };

  return { ...data, setFanOn, setMode, setThresholds };
}

