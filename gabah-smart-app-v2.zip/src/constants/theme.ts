import '@/global.css';
import { Platform } from 'react-native';

export const Palette = {
  brand: '#3DB45A',
  navy: '#293751',
  yellow: '#EEB742',
  cream: '#FFF2D7',
  night: '#111210',
};

export const Colors = {
  light: {
    // Gabah Smart Palette - Light
    brand: '#3DB45A',
    navy: '#293751',
    yellow: '#EEB742',
    cream: '#FFF2D7',
    night: '#111210',
    page: '#fff8e9',
    surface: '#fff2d7',
    soft: '#f8e7c5',
    ink: '#293751',
    mutedText: '#687186',
    line: 'rgba(41, 55, 81, 0.14)',
    card: '#293751',
    cardText: '#ffffff',
    cardMuted: '#c6ccda',
    nav: '#293751',
    navMuted: '#b9c0cb',
    danger: '#f05b67',
    success: '#3db45a',

    // Standard Expo / Theme tokens for compatibility
    text: '#293751',
    background: '#fff8e9',
    backgroundElement: '#fff2d7',
    backgroundSelected: '#f8e7c5',
    textSecondary: '#687186',
    tint: '#3DB45A',
    icon: '#687186',
    tabIconDefault: '#b9c0cb',
    tabIconSelected: '#3DB45A',
  },
  dark: {
    // Gabah Smart Palette - Dark Mode (Murni Hitam & Abu-abu untuk Card, Teks Jelas & Kontras)
    brand: '#3DB45A',
    navy: '#18191c',
    yellow: '#EEB742',
    cream: '#26282c',
    night: '#0e0f10',
    page: '#0e0f10',          // Deep black background
    surface: '#16171a',       // Dark neutral gray surface
    soft: '#222428',          // Medium neutral gray
    ink: '#f9fafb',           // Crisp clear white text
    mutedText: '#9ca3af',     // High-contrast readable gray text
    line: 'rgba(255, 255, 255, 0.12)', // Subtle gray border
    card: '#18191c',          // Pure dark-gray/black card (no navy/blue tint)
    cardText: '#f9fafb',      // Bright crisp white for card title & metrics
    cardMuted: '#9ca3af',     // Clear light-gray for card labels
    nav: '#121315',           // Deep dark gray/black bottom nav
    navMuted: '#9ca3af',      // High-contrast nav text
    danger: '#ff654a',
    success: '#3db45a',

    // Standard Expo / Theme tokens for compatibility
    text: '#f9fafb',
    background: '#0e0f10',
    backgroundElement: '#16171a',
    backgroundSelected: '#222428',
    textSecondary: '#9ca3af',
    tint: '#3DB45A',
    icon: '#9ca3af',
    tabIconDefault: '#9ca3af',
    tabIconSelected: '#3DB45A',
  },
};

export type Theme = 'light' | 'dark';
export type ColorTheme = typeof Colors.light;
export type ThemeColor = keyof typeof Colors.light;

export const Fonts = {
  calSans: 'Cal Sans',
  regular: Platform.select({
    web: "'Cal Sans', Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    default: 'Cal Sans',
  }),
  sans: Platform.select({
    web: "'Cal Sans', Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    default: 'Cal Sans',
  }),
  serif: 'serif',
  rounded: 'normal',
  mono: Platform.select({
    web: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
    default: 'monospace',
  }),
};

export const Spacing = {
  half: 2,
  one: 4,
  two: 8,
  three: 16,
  four: 24,
  five: 32,
  six: 64,
} as const;

export const BottomTabInset = Platform.select({ ios: 50, android: 80 }) ?? 0;
export const MaxContentWidth = 800;
