import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  SafeAreaView,
  useWindowDimensions,
  ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Brand } from '@/components/Brand';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

const onboardingSlides = [
  {
    image: require('@/../assets/images/6c9fe.png'),
    title: 'Gabah Berkualitas',
    description: 'Jaga kualitas gabah di setiap gudang.',
  },
  {
    image: require('@/../assets/images/d4856.png'),
    title: 'Kontrol Cerdas',
    description: 'Pantau sensor dan kendalikan perangkat secara otomatis.',
  },
  {
    image: require('@/../assets/images/9ac12.png'),
    title: 'Didampingi Geby AI',
    description: 'Dapatkan analisis dan saran untuk kondisi gudang.',
  },
];

export default function IndexScreen() {
  const router = useRouter();
  const { colors, isOnboarded, setIsOnboarded, isReady } = useApp();
  const { width } = useWindowDimensions();
  const [slide, setSlide] = useState(0);

  const isWide = width >= 768;

  useEffect(() => {
    if (isReady && isOnboarded) {
      router.replace('/warehouses');
    }
  }, [isReady, isOnboarded]);

  const finish = () => {
    setIsOnboarded(true);
    router.replace('/warehouses');
  };

  if (!isReady) {
    return null;
  }

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View
          style={[
            styles.card,
            {
              backgroundColor: colors.surface,
              borderColor: colors.line,
            },
          ]}
        >
          {/* Header */}
          <View style={styles.header}>
            <Brand />
            <TouchableOpacity
              onPress={finish}
              style={[styles.skipButton, { borderColor: colors.line, backgroundColor: colors.soft }]}
            >
              <Text style={[styles.skipText, { color: colors.ink }]}>Lewati</Text>
            </TouchableOpacity>
          </View>

          {/* Content Body */}
          <View style={[styles.body, isWide && styles.bodyWide]}>
            <View style={[styles.textCol, isWide && styles.textColWide]}>
              <Text style={[styles.stepText, { color: colors.brand }]}>
                LANGKAH {slide + 1} DARI 3
              </Text>
              <Text style={[styles.title, { color: colors.ink }]}>
                {onboardingSlides[slide].title}
              </Text>
              <Text style={[styles.description, { color: colors.mutedText }]}>
                {onboardingSlides[slide].description}
              </Text>

              {/* Dots */}
              <View style={styles.dotsRow}>
                {onboardingSlides.map((_, index) => (
                  <TouchableOpacity
                    key={index}
                    onPress={() => setSlide(index)}
                    style={[
                      styles.dot,
                      index === slide
                        ? [styles.activeDot, { backgroundColor: colors.brand }]
                        : [styles.inactiveDot, { backgroundColor: colors.line }],
                    ]}
                  />
                ))}
              </View>
            </View>

            {/* Illustration */}
            <View
              style={[
                styles.imageBox,
                { backgroundColor: colors.cream },
                isWide && styles.imageBoxWide,
              ]}
            >
              <Image
                source={onboardingSlides[slide].image}
                style={styles.image}
                resizeMode="contain"
              />
            </View>
          </View>

          {/* Footer Controls */}
          <View style={[styles.footer, { borderTopColor: colors.line }]}>
            <TouchableOpacity
              onPress={() => setSlide((curr) => Math.max(0, curr - 1))}
              disabled={slide === 0}
              style={[styles.prevButton, slide === 0 && { opacity: 0 }]}
            >
              <Text style={[styles.prevText, { color: colors.mutedText }]}>Sebelumnya</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => (slide === 2 ? finish() : setSlide((curr) => curr + 1))}
              style={[styles.nextButton, { backgroundColor: colors.brand }]}
            >
              <Text style={styles.nextText}>
                {slide === 2 ? 'Mulai Sekarang' : 'Selanjutnya'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: '100%',
    maxWidth: 960,
    borderRadius: 32,
    borderWidth: 1,
    padding: 24,
    shadowColor: '#293751',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.08,
    shadowRadius: 30,
    elevation: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  skipButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  skipText: {
    fontSize: 13,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  body: {
    paddingVertical: 32,
    gap: 28,
  },
  bodyWide: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 48,
  },
  textCol: {
    flex: 1,
  },
  textColWide: {
    paddingRight: 24,
  },
  stepText: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
    fontFamily: Fonts.calSans,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    marginTop: 12,
    lineHeight: 40,
    fontFamily: Fonts.calSans,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    marginTop: 12,
    fontFamily: Fonts.calSans,
  },
  dotsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 24,
  },
  dot: {
    height: 8,
    borderRadius: 4,
  },
  activeDot: {
    width: 32,
  },
  inactiveDot: {
    width: 8,
  },
  imageBox: {
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    minHeight: 240,
  },
  imageBoxWide: {
    width: 340,
    minHeight: 340,
  },
  image: {
    width: 200,
    height: 200,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    paddingTop: 20,
  },
  prevButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  prevText: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  nextButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    shadowColor: '#3DB45A',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 4,
  },
  nextText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});
