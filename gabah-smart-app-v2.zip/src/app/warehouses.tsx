import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  useWindowDimensions,
  Modal,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Warehouse, Plus, ChevronRight, Trash2, AlertTriangle } from 'lucide-react-native';
import { AppHeader } from '@/components/AppHeader';
import { AddWarehouseModal } from '@/components/AddWarehouseModal';
import { WarehouseSensorStats } from '@/components/WarehouseSensorStats';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

export default function WarehousesScreen() {
  const router = useRouter();
  const { colors, warehouses, removeWarehouse, setSelectedWarehouseId } = useApp();
  const { width } = useWindowDimensions();
  const [addOpen, setAddOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const numColumns = width >= 1024 ? 3 : width >= 640 ? 2 : 1;

  const handleSelectWarehouse = (id: string) => {
    setSelectedWarehouseId(id);
    router.push('/warehouse/dashboard');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <AppHeader />

      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.topSection}>
          <View>
            <Text style={[styles.badge, { color: colors.brand }]}>MANAJEMEN GABAH</Text>
            <Text style={[styles.heading, { color: colors.ink }]}>Gudang terhubung</Text>
            <Text style={[styles.subheading, { color: colors.mutedText }]}>
              Pantau setiap gudang yang terhubung ke sistem IoT Gabah Smart.
            </Text>
          </View>

          <TouchableOpacity
            onPress={() => setAddOpen(true)}
            style={[styles.addBtn, { backgroundColor: colors.brand }]}
          >
            <Plus size={18} color="#ffffff" />
            <Text style={styles.addBtnText}>Tambah Gudang</Text>
          </TouchableOpacity>
        </View>

        {warehouses.length === 0 ? (
          <View
            style={[
              styles.emptyCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.line,
              },
            ]}
          >
            <View style={[styles.emptyIconBox, { backgroundColor: 'rgba(61, 180, 90, 0.1)' }]}>
              <Warehouse size={36} color={colors.brand} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.ink }]}>Belum ada gudang</Text>
            <Text style={[styles.emptyDesc, { color: colors.mutedText }]}>
              Tambahkan koneksi ESP32 pertama untuk mulai memantau kondisi gabah.
            </Text>
            <TouchableOpacity
              onPress={() => setAddOpen(true)}
              style={[styles.emptyBtn, { backgroundColor: colors.brand }]}
            >
              <Plus size={18} color="#ffffff" />
              <Text style={styles.emptyBtnText}>Hubungkan Gudang</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.grid}>
            {warehouses.map((item) => (
              <View
                key={item.id}
                style={[
                  styles.card,
                  {
                    backgroundColor: colors.card,
                    borderColor: colors.line,
                    width: numColumns === 1 ? '100%' : `${100 / numColumns - 1.5}%`,
                  },
                ]}
              >
                <TouchableOpacity
                  onPress={() => handleSelectWarehouse(item.id)}
                  style={styles.cardHeader}
                  activeOpacity={0.8}
                >
                  <View style={styles.cardLeft}>
                    <View style={[styles.warehouseIconBox, { backgroundColor: colors.brand }]}>
                      <Warehouse size={22} color="#ffffff" />
                    </View>
                    <View style={styles.cardInfo}>
                      <Text style={[styles.cardTitle, { color: colors.cardText }]}>
                        {item.name}
                      </Text>
                      <View style={styles.onlineBadge}>
                        <View style={[styles.onlineDot, { backgroundColor: colors.success }]} />
                        <Text style={[styles.onlineText, { color: colors.success }]}>Online</Text>
                      </View>
                    </View>
                  </View>
                  <ChevronRight size={20} color={colors.cardMuted} />
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleSelectWarehouse(item.id)}
                  style={styles.cardStats}
                >
                  <WarehouseSensorStats pairingCode={item.pairingCode} colors={colors} />
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setDeleteId(item.id)}
                  style={styles.deleteBtn}
                >
                  <Trash2 size={16} color={colors.danger} />
                  <Text style={[styles.deleteText, { color: colors.danger }]}>
                    Putuskan koneksi
                  </Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      <AddWarehouseModal visible={addOpen} onClose={() => setAddOpen(false)} />

      {/* Delete Confirmation Modal */}
      <Modal visible={!!deleteId} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.deleteModalCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.line,
              },
            ]}
          >
            <AlertTriangle size={36} color={colors.danger} />
            <Text style={[styles.deleteModalTitle, { color: colors.ink }]}>
              Putuskan gudang?
            </Text>
            <Text style={[styles.deleteModalDesc, { color: colors.mutedText }]}>
              Data koneksi gudang akan dihapus dari aplikasi ini.
            </Text>

            <View style={styles.deleteModalActions}>
              <TouchableOpacity
                onPress={() => setDeleteId(null)}
                style={[styles.modalCancelBtn, { borderColor: colors.line }]}
              >
                <Text style={[styles.modalCancelText, { color: colors.ink }]}>Batal</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  if (deleteId) removeWarehouse(deleteId);
                  setDeleteId(null);
                }}
                style={[styles.modalConfirmBtn, { backgroundColor: colors.danger }]}
              >
                <Text style={styles.modalConfirmText}>Putuskan</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    padding: 20,
    maxWidth: 1120,
    width: '100%',
    alignSelf: 'center',
    paddingBottom: 40,
  },
  topSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    flexWrap: 'wrap',
    gap: 16,
    marginBottom: 24,
  },
  badge: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
    fontFamily: Fonts.calSans,
  },
  heading: {
    fontSize: 30,
    fontWeight: '700',
    marginTop: 6,
    fontFamily: Fonts.calSans,
  },
  subheading: {
    fontSize: 14,
    marginTop: 4,
    fontFamily: Fonts.calSans,
  },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 16,
    gap: 8,
  },
  addBtnText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  emptyCard: {
    borderRadius: 28,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    padding: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  emptyIconBox: {
    width: 72,
    height: 72,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginTop: 18,
    fontFamily: Fonts.calSans,
  },
  emptyDesc: {
    fontSize: 14,
    textAlign: 'center',
    marginTop: 6,
    maxWidth: 320,
    fontFamily: Fonts.calSans,
  },
  emptyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 16,
    gap: 8,
    marginTop: 20,
  },
  emptyBtnText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 18,
    shadowColor: '#293751',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  warehouseIconBox: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardInfo: {
    gap: 3,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  onlineBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  onlineDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  onlineText: {
    fontSize: 12,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  cardStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    marginTop: 16,
    paddingTop: 12,
  },
  statItem: {
    fontSize: 13,
    fontFamily: Fonts.calSans,
  },
  statValue: {
    fontWeight: '700',
  },
  deleteBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 14,
    paddingTop: 4,
  },
  deleteText: {
    fontSize: 12,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(17, 18, 16, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  deleteModalCard: {
    width: '100%',
    maxWidth: 380,
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 8,
  },
  deleteModalTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginTop: 14,
    fontFamily: Fonts.calSans,
  },
  deleteModalDesc: {
    fontSize: 13,
    textAlign: 'center',
    marginTop: 6,
    fontFamily: Fonts.calSans,
  },
  deleteModalActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 22,
    width: '100%',
  },
  modalCancelBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  modalConfirmBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 14,
    alignItems: 'center',
  },
  modalConfirmText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});

