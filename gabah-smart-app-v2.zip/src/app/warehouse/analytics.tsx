import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import { DetailHeader } from '@/components/DetailHeader';
import { DetailNav } from '@/components/DetailNav';
import { GebyFloatingButton } from '@/components/GebyFloatingButton';
import { SvgChart } from '@/components/LineChart';
import { useApp } from '@/hooks/use-app-context';
import { useWarehouseSensor } from '@/hooks/use-warehouse-sensor';
import { Fonts } from '@/constants/theme';

// Fallback data jika Firebase belum ada data historis
const FALLBACK_DATA = [
  { time: '09:00', temp: 23, hum: 58 },
  { time: '10:00', temp: 25, hum: 61 },
  { time: '11:00', temp: 27, hum: 64 },
  { time: '12:00', temp: 29, hum: 68 },
  { time: '13:00', temp: 28, hum: 65 },
];

export default function AnalyticsScreen() {
  const { colors, warehouses, selectedWarehouseId, theme } = useApp();
  const [range, setRange] = useState('Hari');

  const warehouse = warehouses.find((w) => w.id === selectedWarehouseId) || warehouses[0];
  const warehouseName = warehouse ? warehouse.name : 'Gudang Utama';

  const sensor = useWarehouseSensor(warehouse?.pairingCode);

  const isDark = theme === 'dark';

  // Gunakan data log dari Firebase untuk chart jika tersedia
  const chartData =
    sensor.logs.length >= 2
      ? sensor.logs
          .filter((l) => !l.isAlert)
          .slice(0, 10)
          .map((log) => ({
            time: log.time,
            temp: sensor.temperature ?? 0,
            hum: sensor.humidity ?? 0,
          }))
      : FALLBACK_DATA;

  // Log peristiwa dari Firebase, fallback ke dummy jika kosong
  const eventLogs =
    sensor.logs.length > 0
      ? sensor.logs
      : [
          { text: 'Belum ada log — menunggu data dari ESP32', time: '—', isAlert: false },
        ];

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <DetailHeader title="Analisis Data" subtitle={warehouseName} />

      <ScrollView contentContainerStyle={styles.container}>
        {/* Time Range Selector */}
        <View style={[styles.rangeSelector, { backgroundColor: colors.card, borderColor: colors.line, borderWidth: 1 }]}>
          {['Hari', 'Minggu', 'Bulan'].map((item) => (
            <TouchableOpacity
              key={item}
              onPress={() => setRange(item)}
              style={[
                styles.rangeTab,
                range === item && { backgroundColor: isDark ? '#26282c' : colors.cream },
              ]}
            >
              <Text
                style={[
                  styles.rangeText,
                  {
                    color: range === item ? (isDark ? '#f9fafb' : '#293751') : colors.cardMuted,
                    fontWeight: range === item ? '700' : '500',
                  },
                ]}
              >
                {item}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Chart Panel */}
        <View
          style={[
            styles.chartCard,
            { backgroundColor: colors.card, borderColor: colors.line },
          ]}
        >
          {/* Legend */}
          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: colors.yellow }]} />
              <Text style={[styles.legendText, { color: colors.cardMuted }]}>Suhu (°C)</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: colors.success }]} />
              <Text style={[styles.legendText, { color: colors.cardMuted }]}>Kelembapan (%)</Text>
            </View>
            {!sensor.connected && (
              <Text style={[styles.legendText, { color: colors.cardMuted, fontStyle: 'italic' }]}>
                (data contoh)
              </Text>
            )}
          </View>

          {/* Cross-platform SVG Chart with Hover & Touch Tooltip */}
          <SvgChart data={chartData} height={260} />
        </View>

        {/* Real-time Values */}
        {sensor.connected && (
          <View style={[styles.liveRow, { borderColor: colors.line }]}>
            <View style={styles.liveItem}>
              <Text style={[styles.liveLabel, { color: colors.cardMuted }]}>Suhu Terkini</Text>
              <Text style={[styles.liveValue, { color: colors.yellow }]}>
                {sensor.temperature !== null ? `${sensor.temperature.toFixed(1)}°C` : '—'}
              </Text>
            </View>
            <View style={[styles.liveDivider, { backgroundColor: colors.line }]} />
            <View style={styles.liveItem}>
              <Text style={[styles.liveLabel, { color: colors.cardMuted }]}>Kelembapan Terkini</Text>
              <Text style={[styles.liveValue, { color: colors.success }]}>
                {sensor.humidity !== null ? `${sensor.humidity.toFixed(0)}%` : '—'}
              </Text>
            </View>
          </View>
        )}

        {/* Event Logs */}
        <Text style={[styles.sectionTitle, { color: colors.ink }]}>Log Peristiwa</Text>
        <View style={styles.logList}>
          {eventLogs.map((log, idx) => (
            <View
              key={idx}
              style={[
                styles.logCard,
                { backgroundColor: colors.card, borderColor: colors.line },
              ]}
            >
              <View style={styles.logHeader}>
                <View
                  style={[
                    styles.logStatusDot,
                    { backgroundColor: log.isAlert ? colors.danger : colors.success },
                  ]}
                />
                <Text style={[styles.logText, { color: colors.cardText }]}>{log.text}</Text>
              </View>
              <Text style={[styles.logTime, { color: colors.cardMuted }]}>{log.time}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <GebyFloatingButton />
      <DetailNav />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    padding: 16,
    maxWidth: 880,
    width: '100%',
    alignSelf: 'center',
    paddingBottom: 90,
  },
  rangeSelector: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 4,
    marginBottom: 16,
  },
  rangeTab: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
  },
  rangeText: {
    fontSize: 14,
    fontFamily: Fonts.calSans,
  },
  chartCard: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 18,
    shadowColor: '#293751',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 4,
  },
  legend: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 12,
    flexWrap: 'wrap',
    alignItems: 'center',
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: 12,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  liveRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    borderWidth: 1,
    borderRadius: 20,
    padding: 16,
    marginTop: 16,
  },
  liveItem: {
    alignItems: 'center',
  },
  liveLabel: {
    fontSize: 12,
    fontFamily: Fonts.calSans,
  },
  liveValue: {
    fontSize: 28,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
    marginTop: 4,
  },
  liveDivider: {
    width: 1,
    height: '100%',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginTop: 24,
    marginBottom: 12,
    fontFamily: Fonts.calSans,
  },
  logList: {
    gap: 10,
  },
  logCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 14,
  },
  logHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  logStatusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  logText: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
    flex: 1,
  },
  logTime: {
    fontSize: 12,
    marginTop: 4,
    marginLeft: 18,
    fontFamily: Fonts.calSans,
  },
});
