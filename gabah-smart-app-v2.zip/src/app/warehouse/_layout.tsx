import React from 'react';
import { Stack } from 'expo-router';

export default function WarehouseLayout() {
  return (
    <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
      <Stack.Screen name="dashboard" />
      <Stack.Screen name="analytics" />
      <Stack.Screen name="controls" />
      <Stack.Screen name="insights" />
      <Stack.Screen name="geby" />
    </Stack>
  );
}

