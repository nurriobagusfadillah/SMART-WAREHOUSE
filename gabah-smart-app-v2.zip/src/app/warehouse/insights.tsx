import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { AlertTriangle, CloudRain, CheckCircle } from 'lucide-react-native';
import { DetailHeader } from '@/components/DetailHeader';
import { DetailNav } from '@/components/DetailNav';
import { GebyFloatingButton } from '@/components/GebyFloatingButton';
import { SvgChart } from '@/components/LineChart';
import { useApp } from '@/hooks/use-app-context';
import { Fonts } from '@/constants/theme';

const predictionData = [
  { time: '13:00', hum: 65 },
  { time: '14:00', hum: 69 },
  { time: '15:00', hum: 76 },
  { time: '16:00', hum: 80 },
];

export default function InsightsScreen() {
  const { colors, warehouses, selectedWarehouseId, theme } = useApp();
  const { width } = useWindowDimensions();
  const [fanBoosted, setFanBoosted] = useState(false);

  const warehouse = warehouses.find((w) => w.id === selectedWarehouseId) || warehouses[0];
  const warehouseName = warehouse ? warehouse.name : 'Gudang Utama';

  const isWide = width >= 768;

  const isDark = theme === 'dark';

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <DetailHeader title="Wawasan AI" subtitle={warehouseName} />

      <ScrollView contentContainerStyle={styles.container}>
        <View style={[styles.grid, isWide && styles.gridWide]}>
          {/* BMKG Forecast Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.halfWidth,
            ]}
          >
            <View style={styles.cardHeaderSmall}>
              <CloudRain size={18} color={colors.cardMuted} />
              <Text style={[styles.cardHeaderLabel, { color: colors.cardMuted }]}>
                Data API BMKG
              </Text>
            </View>
            <Text style={[styles.forecastTitle, { color: colors.cardText }]}>
              Hujan Lebat
            </Text>
            <Text style={[styles.forecastDesc, { color: colors.yellow }]}>
              Diperkirakan dalam 2 jam
            </Text>
          </View>

          {/* AI Prediction Alert Card */}
          <View
            style={[
              styles.alertCard,
              {
                backgroundColor: isDark ? colors.card : colors.yellow,
                borderColor: isDark ? colors.yellow : colors.line,
                borderWidth: isDark ? 1.5 : 1,
              },
              isWide && styles.halfWidth,
            ]}
          >
            <View style={styles.alertHeader}>
              <AlertTriangle size={20} color={isDark ? colors.yellow : '#293751'} />
              <Text style={[styles.alertTitle, { color: isDark ? colors.cardText : '#293751' }]}>
                Peringatan Prediksi
              </Text>
            </View>
            <Text style={[styles.alertText, { color: isDark ? colors.cardMuted : '#293751' }]}>
              Kelembapan diprediksi melewati batas 75% dalam 3 jam. Aktifkan kipas lebih awal untuk menjaga kualitas gabah.
            </Text>
            <TouchableOpacity
              onPress={() => setFanBoosted(true)}
              style={[
                styles.alertActionBtn,
                { backgroundColor: isDark ? '#26282c' : colors.cream },
              ]}
            >
              {fanBoosted ? (
                <View style={styles.btnRow}>
                  <CheckCircle size={16} color={isDark ? colors.brand : '#293751'} />
                  <Text style={[styles.alertActionText, { color: isDark ? colors.cardText : '#293751' }]}>
                    Kipas Telah Diaktifkan
                  </Text>
                </View>
              ) : (
                <Text style={[styles.alertActionText, { color: isDark ? colors.cardText : '#293751' }]}>
                  Aktifkan Kipas Lebih Awal
                </Text>
              )}
            </TouchableOpacity>
          </View>

          {/* Future Trend Chart */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.fullWidth,
            ]}
          >
            <Text style={[styles.chartTitle, { color: colors.cardText }]}>
              Tren ke Depan (Prediksi Kelembapan %)
            </Text>
            <SvgChart data={predictionData} height={240} isPrediction />
          </View>
        </View>
      </ScrollView>

      <GebyFloatingButton />
      <DetailNav />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    padding: 16,
    maxWidth: 880,
    width: '100%',
    alignSelf: 'center',
    paddingBottom: 90,
  },
  grid: {
    gap: 16,
  },
  gridWide: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  fullWidth: {
    width: '100%',
  },
  halfWidth: {
    width: '48.5%',
  },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
    shadowColor: '#293751',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 4,
  },
  cardHeaderSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardHeaderLabel: {
    fontSize: 13,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  forecastTitle: {
    fontSize: 28,
    fontWeight: '700',
    marginTop: 14,
    fontFamily: Fonts.calSans,
  },
  forecastDesc: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 4,
    fontFamily: Fonts.calSans,
  },
  alertCard: {
    borderRadius: 24,
    padding: 20,
    shadowColor: '#EEB742',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 4,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  alertTitle: {
    color: '#293751',
    fontSize: 16,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  alertText: {
    color: '#293751',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 10,
    fontFamily: Fonts.calSans,
  },
  alertActionBtn: {
    marginTop: 18,
    paddingVertical: 12,
    borderRadius: 14,
    alignItems: 'center',
  },
  btnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  alertActionText: {
    color: '#293751',
    fontSize: 13,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 10,
    fontFamily: Fonts.calSans,
  },
});

