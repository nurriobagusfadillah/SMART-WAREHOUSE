import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  useWindowDimensions,
  ActivityIndicator,
} from 'react-native';
import { CloudRain, Thermometer, Droplets, Fan, WifiOff } from 'lucide-react-native';
import { DetailHeader } from '@/components/DetailHeader';
import { DetailNav } from '@/components/DetailNav';
import { GebyFloatingButton } from '@/components/GebyFloatingButton';
import { useApp } from '@/hooks/use-app-context';
import { useWarehouseSensor } from '@/hooks/use-warehouse-sensor';
import { Fonts } from '@/constants/theme';

export default function DashboardScreen() {
  const { colors, warehouses, selectedWarehouseId, theme } = useApp();
  const { width } = useWindowDimensions();

  const warehouse = warehouses.find((w) => w.id === selectedWarehouseId) || warehouses[0];
  const warehouseName = warehouse ? warehouse.name : 'Gudang Utama';

  const sensor = useWarehouseSensor(warehouse?.pairingCode);

  const isWide = width >= 768;
  const isDark = theme === 'dark';

  const handleModeChange = async (newMode: 'auto' | 'manual') => {
    await sensor.setMode(newMode);
  };

  const handleFanToggle = async () => {
    await sensor.setFanOn(!sensor.fanOn);
  };

  const tempLabel =
    sensor.temperature === null ? '—' : `${sensor.temperature.toFixed(1)}`;
  const tempStatus =
    sensor.temperature === null
      ? 'Menunggu data...'
      : sensor.temperature > 30
      ? 'Peringatan: Panas'
      : sensor.temperature < 20
      ? 'Peringatan: Dingin'
      : 'Suhu Normal';
  const tempStatusColor =
    sensor.temperature === null
      ? colors.cardMuted
      : sensor.temperature > 30 || sensor.temperature < 20
      ? colors.danger
      : colors.success;

  const humLabel =
    sensor.humidity === null ? '—' : `${sensor.humidity.toFixed(0)}`;
  const humStatus =
    sensor.humidity === null
      ? 'Menunggu data...'
      : sensor.humidity > 80
      ? 'Peringatan: Terlalu Lembap'
      : sensor.humidity < 40
      ? 'Peringatan: Terlalu Kering'
      : 'Kondisi Optimal';
  const humStatusColor =
    sensor.humidity === null
      ? colors.cardMuted
      : sensor.humidity > 80 || sensor.humidity < 40
      ? colors.danger
      : colors.success;

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <DetailHeader title="Ringkasan" subtitle={warehouseName} />

      <ScrollView contentContainerStyle={styles.container}>
        {/* Offline Banner */}
        {!sensor.loading && !sensor.connected && (
          <View style={[styles.offlineBanner, { backgroundColor: colors.danger + '22', borderColor: colors.danger }]}>
            <WifiOff size={16} color={colors.danger} />
            <Text style={[styles.offlineText, { color: colors.danger }]}>
              ESP32 tidak terdeteksi — pastikan perangkat menyala dan terhubung ke WiFi
            </Text>
          </View>
        )}

        <View style={[styles.grid, isWide && styles.gridWide]}>
          {/* Weather Card — static placeholder (bisa disambungkan ke API cuaca) */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.fullWidth,
            ]}
          >
            <View style={styles.cardHeaderSmall}>
              <CloudRain size={18} color={colors.cardMuted} />
              <Text style={[styles.cardHeaderLabel, { color: colors.cardMuted }]}>
                Data Google Cuaca
              </Text>
            </View>
            <View style={styles.weatherBody}>
              <View>
                <Text style={[styles.weatherStatus, { color: colors.yellow }]}>Hujan Lebat</Text>
                <Text style={[styles.weatherDesc, { color: colors.cardMuted }]}>
                  Diperkirakan dalam 2 jam
                </Text>
              </View>
              <View style={styles.weatherIconCircle}>
                <CloudRain size={28} color="#ffffff" />
              </View>
            </View>
          </View>

          {/* Temperature Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.halfWidth,
            ]}
          >
            <View style={styles.cardHeaderSmall}>
              <Thermometer size={18} color={colors.danger} />
              <Text style={[styles.cardHeaderLabel, { color: colors.cardMuted }]}>Suhu</Text>
            </View>
            {sensor.loading ? (
              <ActivityIndicator style={styles.loader} color={colors.brand} />
            ) : (
              <>
                <Text style={[styles.metricValue, { color: colors.cardText }]}>
                  {tempLabel}
                  <Text style={[styles.metricUnit, { color: colors.cardMuted }]}>
                    {sensor.temperature !== null ? '°C' : ''}
                  </Text>
                </Text>
                <Text style={[styles.metricWarning, { color: tempStatusColor }]}>
                  {tempStatus}
                </Text>
              </>
            )}
          </View>

          {/* Humidity Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.halfWidth,
            ]}
          >
            <View style={styles.cardHeaderSmall}>
              <Droplets size={18} color={colors.success} />
              <Text style={[styles.cardHeaderLabel, { color: colors.cardMuted }]}>Kelembapan</Text>
            </View>
            {sensor.loading ? (
              <ActivityIndicator style={styles.loader} color={colors.brand} />
            ) : (
              <>
                <Text style={[styles.metricValue, { color: colors.cardText }]}>
                  {humLabel}
                  <Text style={[styles.metricUnit, { color: colors.cardMuted }]}>
                    {sensor.humidity !== null ? '%' : ''}
                  </Text>
                </Text>
                <Text style={[styles.metricWarning, { color: humStatusColor }]}>
                  {humStatus}
                </Text>
              </>
            )}
          </View>

          {/* Fan Automation Controls Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.fullWidth,
            ]}
          >
            {/* Mode Toggle */}
            <View style={styles.modeToggleBar}>
              <TouchableOpacity
                onPress={() => handleModeChange('auto')}
                style={[
                  styles.modeButton,
                  sensor.mode === 'auto' && { backgroundColor: isDark ? '#26282c' : colors.cream },
                ]}
              >
                <Text
                  style={[
                    styles.modeButtonText,
                    { color: sensor.mode === 'auto' ? (isDark ? '#f9fafb' : '#293751') : colors.cardMuted },
                  ]}
                >
                  Otomatis
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handleModeChange('manual')}
                style={[
                  styles.modeButton,
                  sensor.mode === 'manual' && { backgroundColor: isDark ? '#26282c' : colors.cream },
                ]}
              >
                <Text
                  style={[
                    styles.modeButtonText,
                    { color: sensor.mode === 'manual' ? (isDark ? '#f9fafb' : '#293751') : colors.cardMuted },
                  ]}
                >
                  Manual
                </Text>
              </TouchableOpacity>
            </View>

            {/* Fan Switch */}
            <View style={styles.fanRow}>
              <View style={styles.fanLeft}>
                <View style={[styles.fanIconCircle, { backgroundColor: 'rgba(61, 180, 90, 0.2)' }]}>
                  <Fan size={22} color={colors.brand} />
                </View>
                <View>
                  <Text style={[styles.fanTitle, { color: colors.cardText }]}>Kipas Pembuang</Text>
                  <Text style={[styles.fanDesc, { color: colors.cardMuted }]}>
                    {sensor.mode === 'auto' ? 'Dikontrol otomatis' : 'Kontrol daya'}
                  </Text>
                </View>
              </View>

              <TouchableOpacity
                disabled={sensor.mode === 'auto' || !sensor.connected}
                onPress={handleFanToggle}
                style={[
                  styles.switchTrack,
                  {
                    backgroundColor: sensor.fanOn ? colors.brand : 'rgba(255, 255, 255, 0.15)',
                    opacity: sensor.mode === 'auto' || !sensor.connected ? 0.5 : 1,
                  },
                ]}
              >
                <View style={[styles.switchThumb, sensor.fanOn && styles.switchThumbActive]} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>

      <GebyFloatingButton />
      <DetailNav />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    padding: 16,
    maxWidth: 880,
    width: '100%',
    alignSelf: 'center',
    paddingBottom: 90,
  },
  offlineBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 16,
  },
  offlineText: {
    fontSize: 13,
    flex: 1,
    fontFamily: Fonts.calSans,
  },
  grid: {
    gap: 16,
  },
  gridWide: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  fullWidth: {
    width: '100%',
  },
  halfWidth: {
    width: '48.5%',
  },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
    shadowColor: '#293751',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 4,
  },
  cardHeaderSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardHeaderLabel: {
    fontSize: 13,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  loader: {
    marginTop: 20,
    marginBottom: 10,
  },
  weatherBody: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: 18,
  },
  weatherStatus: {
    fontSize: 28,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  weatherDesc: {
    fontSize: 13,
    marginTop: 4,
    fontFamily: Fonts.calSans,
  },
  weatherIconCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  metricValue: {
    fontSize: 40,
    fontWeight: '700',
    marginTop: 14,
    fontFamily: Fonts.calSans,
  },
  metricUnit: {
    fontSize: 22,
    fontWeight: '400',
  },
  metricWarning: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 6,
    fontFamily: Fonts.calSans,
  },
  modeToggleBar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 0, 0, 0.18)',
    borderRadius: 14,
    padding: 4,
  },
  modeButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  modeButtonText: {
    fontSize: 14,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  fanRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 20,
  },
  fanLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  fanIconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fanTitle: {
    fontSize: 15,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  fanDesc: {
    fontSize: 12,
    marginTop: 2,
    fontFamily: Fonts.calSans,
  },
  switchTrack: {
    width: 54,
    height: 32,
    borderRadius: 16,
    padding: 3,
    justifyContent: 'center',
  },
  switchThumb: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: '#ffffff',
  },
  switchThumbActive: {
    alignSelf: 'flex-end',
  },
});
