import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Animated,
  Modal,
} from 'react-native';

type ScrollViewRef = { scrollToEnd: (opts?: { animated?: boolean }) => void };
import { useRouter } from 'expo-router';
import {
  Bot,
  Send,
  ArrowLeft,
  Plus,
  Search,
  Trash2,
  X,
  MessageSquare,
  Settings2,
  StopCircle,
  ChevronRight,
  Wheat,
} from 'lucide-react-native';
import { useApp } from '@/hooks/use-app-context';
import { useGebyChat } from '@/hooks/use-geby-chat';
import { Fonts } from '@/constants/theme';

// Quick suggestions untuk petani
const QUICK_SUGGESTIONS = [
  '🌡️ Suhu ideal penyimpanan gabah itu berapa?',
  '💧 Kelembapan gudang lagi tinggi, berbahaya ga?',
  '🌀 Kapan kipas sebaiknya dinyalakan?',
  '🍄 Gimana cara tau gabah mulai berjamur?',
  '📊 Kasih tips penyimpanan gabah yang bener dong',
];

// Personalisasi / info petani
type PersonalInfo = {
  name: string;
  region: string;
};

export default function GebyScreen() {
  const router = useRouter();
  const { colors, warehouses, selectedWarehouseId, theme } = useApp();
  const { width: screenWidth } = require('react-native').useWindowDimensions();

  const warehouse = warehouses.find((w) => w.id === selectedWarehouseId) || warehouses[0];
  const warehouseName = warehouse?.name ?? 'Gudang Utama';
  const warehouseContext = warehouse
    ? `${warehouse.name} (kode: ${warehouse.pairingCode})`
    : undefined;

  const {
    conversations,
    messages,
    activeConvId,
    isStreaming,
    streamingText,
    loadHistory,
    newConversation,
    selectConversation,
    deleteConversation,
    sendMessage,
    stopStreaming,
  } = useGebyChat(warehouseContext);

  const [input, setInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [personalInfo, setPersonalInfo] = useState<PersonalInfo>({ name: '', region: '' });
  const [editName, setEditName] = useState('');
  const [editRegion, setEditRegion] = useState('');
  const scrollRef = useRef<ScrollViewRef | null>(null);
  const sidebarAnim = useRef(new Animated.Value(0)).current;

  const isWide = screenWidth >= 1024;
  const isDark = theme === 'dark';

  // Load riwayat saat screen dibuka
  useEffect(() => {
    loadHistory();
  }, []);

  // Auto-scroll ke bawah saat ada pesan baru
  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages.length, streamingText]);

  // Animasi sidebar mobile
  const openSidebar = () => {
    setSidebarOpen(true);
    Animated.spring(sidebarAnim, {
      toValue: 1,
      useNativeDriver: true,
      tension: 80,
      friction: 10,
    }).start();
  };

  const closeSidebar = () => {
    Animated.spring(sidebarAnim, {
      toValue: 0,
      useNativeDriver: true,
      tension: 80,
      friction: 10,
    }).start(() => setSidebarOpen(false));
  };

  const handleSend = () => {
    if (!input.trim() || isStreaming) return;
    const text = input.trim();
    setInput('');
    sendMessage(text);
  };

  const handleSuggestion = (text: string) => {
    sendMessage(text);
  };

  const handleSelectConv = (id: string) => {
    selectConversation(id);
    if (!isWide) closeSidebar();
  };

  const handleNewChat = () => {
    newConversation();
    if (!isWide) closeSidebar();
  };

  const openSettings = () => {
    setEditName(personalInfo.name);
    setEditRegion(personalInfo.region);
    setSettingsOpen(true);
  };

  const saveSettings = () => {
    setPersonalInfo({ name: editName.trim(), region: editRegion.trim() });
    setSettingsOpen(false);
  };

  // Filter percakapan berdasarkan search
  const filteredConversations = searchQuery.trim()
    ? conversations.filter((c) =>
        c.title.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : conversations;

  // Format waktu singkat
  const formatTime = (ts: number) => {
    const d = new Date(ts);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - d.getTime()) / 86400000);
    if (diffDays === 0) return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    if (diffDays === 1) return 'Kemarin';
    if (diffDays < 7) return `${diffDays} hari lalu`;
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
  };

  // ── Sidebar Content ───────────────────────────────────────────────
  const SidebarContent = () => (
    <View style={[styles.sidebar, { backgroundColor: isDark ? '#121315' : colors.card }]}>
      {/* Logo + Close button (mobile) */}
      <View style={styles.sidebarTop}>
        <View style={styles.gebyLogoRow}>
          <View style={[styles.gebyLogoCircle, { backgroundColor: colors.yellow }]}>
            <Wheat size={18} color="#293751" />
          </View>
          <Text style={[styles.gebyLogoText, { color: isDark ? '#f9fafb' : '#ffffff' }]}>
            Geby AI
          </Text>
        </View>
        {!isWide && (
          <TouchableOpacity onPress={closeSidebar} style={styles.closeBtn}>
            <X size={20} color={isDark ? '#9ca3af' : '#c6ccda'} />
          </TouchableOpacity>
        )}
      </View>

      {/* Tombol Percakapan Baru */}
      <TouchableOpacity
        onPress={handleNewChat}
        style={[styles.newChatBtn, { borderColor: isDark ? 'rgba(255,255,255,0.15)' : 'rgba(255,255,255,0.25)' }]}
      >
        <Plus size={16} color="#ffffff" />
        <Text style={styles.newChatText}>Percakapan baru</Text>
      </TouchableOpacity>

      {/* Search */}
      <View style={[styles.searchBar, { backgroundColor: isDark ? '#1e2024' : 'rgba(255,255,255,0.12)', borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.2)' }]}>
        <Search size={14} color={isDark ? '#9ca3af' : '#c6ccda'} />
        <TextInput
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Cari percakapan..."
          placeholderTextColor={isDark ? '#6b7280' : '#94a3b8'}
          style={[styles.searchInput, { color: isDark ? '#f9fafb' : '#ffffff' }]}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <X size={14} color={isDark ? '#9ca3af' : '#c6ccda'} />
          </TouchableOpacity>
        )}
      </View>

      {/* Riwayat */}
      <Text style={[styles.sidebarHeading, { color: isDark ? '#6b7280' : '#94a3b8' }]}>
        RIWAYAT CHAT
      </Text>

      <ScrollView style={styles.historyList} showsVerticalScrollIndicator={false}>
        {filteredConversations.length === 0 ? (
          <View style={styles.emptyHistory}>
            <MessageSquare size={28} color={isDark ? '#374151' : 'rgba(255,255,255,0.2)'} />
            <Text style={[styles.emptyHistoryText, { color: isDark ? '#6b7280' : 'rgba(255,255,255,0.4)' }]}>
              {searchQuery ? 'Tidak ditemukan' : 'Belum ada percakapan'}
            </Text>
          </View>
        ) : (
          filteredConversations.map((conv) => (
            <TouchableOpacity
              key={conv.id}
              onPress={() => handleSelectConv(conv.id)}
              style={[
                styles.historyItem,
                conv.id === activeConvId && {
                  backgroundColor: isDark ? '#1e2024' : 'rgba(255,255,255,0.15)',
                },
              ]}
            >
              <View style={styles.historyItemLeft}>
                <MessageSquare size={14} color={isDark ? '#9ca3af' : '#c6ccda'} />
                <View style={{ flex: 1 }}>
                  <Text
                    style={[styles.historyTitle, { color: isDark ? '#f9fafb' : '#ffffff' }]}
                    numberOfLines={1}
                  >
                    {conv.title}
                  </Text>
                  <Text style={[styles.historyTime, { color: isDark ? '#6b7280' : 'rgba(255,255,255,0.4)' }]}>
                    {formatTime(conv.updatedAt)}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => deleteConversation(conv.id)}
                style={styles.deleteHistBtn}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <Trash2 size={13} color={isDark ? '#4b5563' : 'rgba(255,255,255,0.3)'} />
              </TouchableOpacity>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      {/* Personalisasi */}
      <TouchableOpacity
        onPress={openSettings}
        style={[styles.personalizationBtn, { borderTopColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.15)' }]}
      >
        <View style={styles.personalizationLeft}>
          <View style={[styles.avatarCircle, { backgroundColor: colors.brand }]}>
            <Text style={styles.avatarText}>
              {personalInfo.name ? personalInfo.name[0].toUpperCase() : '🌾'}
            </Text>
          </View>
          <View>
            <Text style={[styles.personalizeName, { color: isDark ? '#f9fafb' : '#ffffff' }]} numberOfLines={1}>
              {personalInfo.name || 'Pak/Bu Petani'}
            </Text>
            <Text style={[styles.personalizeRegion, { color: isDark ? '#6b7280' : 'rgba(255,255,255,0.5)' }]} numberOfLines={1}>
              {personalInfo.region || 'Atur Profil'}
            </Text>
          </View>
        </View>
        <Settings2 size={16} color={isDark ? '#6b7280' : 'rgba(255,255,255,0.4)'} />
      </TouchableOpacity>
    </View>
  );

  // ── Main Chat ─────────────────────────────────────────────────────
  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <View style={styles.root}>

        {/* Sidebar Desktop */}
        {isWide && <SidebarContent />}

        {/* Sidebar Mobile Overlay */}
        {!isWide && sidebarOpen && (
          <TouchableOpacity
            style={styles.sidebarOverlay}
            activeOpacity={1}
            onPress={closeSidebar}
          />
        )}
        {!isWide && sidebarOpen && (
          <Animated.View
            style={[
              styles.mobileSidebar,
              {
                transform: [
                  {
                    translateX: sidebarAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [-280, 0],
                    }),
                  },
                ],
              },
            ]}
          >
            <SidebarContent />
          </Animated.View>
        )}

        {/* Chat Area */}
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.chatMain}
        >
          {/* Header */}
          <View style={[styles.chatHeader, { backgroundColor: colors.surface, borderBottomColor: colors.line }]}>
            <View style={styles.headerLeft}>
              {!isWide && (
                <TouchableOpacity
                  onPress={openSidebar}
                  style={[styles.iconBtn, { borderColor: colors.line }]}
                >
                  <MessageSquare size={18} color={colors.ink} />
                </TouchableOpacity>
              )}
              <TouchableOpacity
                onPress={() => router.back()}
                style={[styles.iconBtn, { borderColor: colors.line }]}
              >
                <ArrowLeft size={18} color={colors.ink} />
              </TouchableOpacity>
              <View style={styles.headerInfo}>
                <Text style={[styles.headerTitle, { color: colors.ink }]}>Geby AI</Text>
                <Text style={[styles.headerSub, { color: colors.mutedText }]}>
                  {personalInfo.name ? `Halo, ${personalInfo.name}! ` : ''}
                  {warehouseName}
                </Text>
              </View>
            </View>

            <View style={[styles.onlineBadge, { backgroundColor: colors.success + '22' }]}>
              <View style={[styles.onlineDot, { backgroundColor: colors.success }]} />
              <Text style={[styles.onlineText, { color: colors.success }]}>Online</Text>
            </View>
          </View>

          {/* Messages */}
          <ScrollView
            ref={scrollRef as any}
            contentContainerStyle={styles.messagesContainer}
            showsVerticalScrollIndicator={false}
          >
            {messages.length === 0 && !isStreaming ? (
              /* Empty / Welcome State */
              <View style={styles.emptyState}>
                <View style={[styles.botCircle, { backgroundColor: colors.yellow }]}>
                  <Wheat size={36} color="#293751" />
                </View>
                <Text style={[styles.emptyTitle, { color: colors.ink }]}>
                  Hai{personalInfo.name ? `, ${personalInfo.name}` : ''}! Geby siap bantu 🌾
                </Text>
                <Text style={[styles.emptyDesc, { color: colors.mutedText }]}>
                  Tanya apa aja soal kondisi gabah, gudang, atau tips penyimpanan. Geby selalu ada buat kamu!
                </Text>

                <View style={styles.suggestionsGrid}>
                  {QUICK_SUGGESTIONS.map((s) => (
                    <TouchableOpacity
                      key={s}
                      onPress={() => handleSuggestion(s)}
                      style={[styles.suggestionCard, { backgroundColor: colors.surface, borderColor: colors.line }]}
                      activeOpacity={0.75}
                    >
                      <Text style={[styles.suggestionText, { color: colors.ink }]}>{s}</Text>
                      <ChevronRight size={14} color={colors.mutedText} />
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            ) : (
              /* Messages List */
              <View style={styles.messagesList}>
                {messages.map((msg, idx) => {
                  const isUser = msg.role === 'user';
                  return (
                    <View
                      key={idx}
                      style={[styles.messageRow, isUser ? styles.rowUser : styles.rowBot]}
                    >
                      {!isUser && (
                        <View style={[styles.botAvatar, { backgroundColor: colors.yellow }]}>
                          <Wheat size={14} color="#293751" />
                        </View>
                      )}
                      <View
                        style={[
                          styles.bubble,
                          isUser
                            ? [styles.bubbleUser, { backgroundColor: colors.brand }]
                            : [styles.bubbleBot, { backgroundColor: colors.surface, borderColor: colors.line }],
                        ]}
                      >
                        <Text style={[styles.bubbleText, { color: isUser ? '#ffffff' : colors.ink }]}>
                          {msg.text}
                        </Text>
                        <Text style={[styles.bubbleTime, { color: isUser ? 'rgba(255,255,255,0.6)' : colors.mutedText }]}>
                          {new Date(msg.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                      </View>
                      {isUser && (
                        <View style={[styles.userAvatar, { backgroundColor: colors.brand }]}>
                          <Text style={styles.userAvatarText}>
                            {personalInfo.name ? personalInfo.name[0].toUpperCase() : '👤'}
                          </Text>
                        </View>
                      )}
                    </View>
                  );
                })}

                {/* Streaming / typing indicator */}
                {isStreaming && (
                  <View style={[styles.messageRow, styles.rowBot]}>
                    <View style={[styles.botAvatar, { backgroundColor: colors.yellow }]}>
                      <Wheat size={14} color="#293751" />
                    </View>
                    <View style={[styles.bubble, styles.bubbleBot, { backgroundColor: colors.surface, borderColor: colors.line }]}>
                      {streamingText ? (
                        <Text style={[styles.bubbleText, { color: colors.ink }]}>
                          {streamingText}
                          <Text style={{ color: colors.brand }}>▌</Text>
                        </Text>
                      ) : (
                        <View style={styles.typingRow}>
                          <ActivityIndicator size="small" color={colors.brand} />
                          <Text style={[styles.typingText, { color: colors.mutedText }]}>
                            Geby lagi mikir...
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                )}
              </View>
            )}
          </ScrollView>

          {/* Input Bar */}
          <View style={[styles.inputBar, { backgroundColor: colors.surface, borderTopColor: colors.line }]}>
            <View style={[styles.inputWrapper, { backgroundColor: colors.soft, borderColor: colors.line }]}>
              <TextInput
                value={input}
                onChangeText={setInput}
                placeholder="Tanya Geby sesuatu..."
                placeholderTextColor={colors.mutedText}
                style={[styles.textInput, { color: colors.ink }]}
                multiline
                maxLength={1000}
                onSubmitEditing={Platform.OS === 'web' ? handleSend : undefined}
                blurOnSubmit={false}
              />
              {isStreaming ? (
                <TouchableOpacity onPress={stopStreaming} style={[styles.sendBtn, { backgroundColor: colors.danger }]}>
                  <StopCircle size={18} color="#ffffff" />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={handleSend}
                  disabled={!input.trim()}
                  style={[styles.sendBtn, { backgroundColor: input.trim() ? colors.brand : colors.cardMuted }]}
                >
                  <Send size={18} color="#ffffff" />
                </TouchableOpacity>
              )}
            </View>
            <Text style={[styles.inputHint, { color: colors.mutedText }]}>
              Didukung oleh Groq • Llama 3.3 70B
            </Text>
          </View>
        </KeyboardAvoidingView>
      </View>

      {/* Settings / Personalisasi Modal */}
      <Modal visible={settingsOpen} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.settingsCard, { backgroundColor: colors.surface, borderColor: colors.line }]}>
            <View style={styles.settingsHeader}>
              <Text style={[styles.settingsTitle, { color: colors.ink }]}>Personalisasi Geby</Text>
              <TouchableOpacity onPress={() => setSettingsOpen(false)}>
                <X size={20} color={colors.mutedText} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.settingsLabel, { color: colors.mutedText }]}>Nama kamu</Text>
            <TextInput
              value={editName}
              onChangeText={setEditName}
              placeholder="Misal: Pak Budi"
              placeholderTextColor={colors.mutedText}
              style={[styles.settingsInput, { borderColor: colors.line, color: colors.ink, backgroundColor: colors.soft }]}
            />

            <Text style={[styles.settingsLabel, { color: colors.mutedText }]}>Daerah / Lokasi gudang</Text>
            <TextInput
              value={editRegion}
              onChangeText={setEditRegion}
              placeholder="Misal: Kendal, Jawa Tengah"
              placeholderTextColor={colors.mutedText}
              style={[styles.settingsInput, { borderColor: colors.line, color: colors.ink, backgroundColor: colors.soft }]}
            />

            <Text style={[styles.settingsHint, { color: colors.mutedText }]}>
              💡 Info ini membantu Geby memberikan saran yang lebih pas buat kondisi kamu.
            </Text>

            <TouchableOpacity onPress={saveSettings} style={[styles.saveBtn, { backgroundColor: colors.brand }]}>
              <Text style={styles.saveBtnText}>Simpan</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  root: { flex: 1, flexDirection: 'row' },

  // ── Sidebar ──────────────────────────────────────────────────────
  sidebar: {
    width: 260,
    borderRightWidth: 1,
    borderRightColor: 'rgba(255,255,255,0.1)',
    paddingTop: 16,
    paddingHorizontal: 14,
    paddingBottom: 0,
    gap: 10,
  },
  mobileSidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 280,
    zIndex: 100,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 12,
  },
  sidebarOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    zIndex: 99,
  },
  sidebarTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  gebyLogoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  gebyLogoCircle: {
    width: 32,
    height: 32,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  gebyLogoText: {
    fontSize: 16,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  closeBtn: {
    padding: 4,
  },
  newChatBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 11,
  },
  newChatText: {
    color: '#ffffff',
    fontSize: 13,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    fontFamily: Fonts.calSans,
    paddingVertical: 0,
  },
  sidebarHeading: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginTop: 6,
    fontFamily: Fonts.calSans,
  },
  historyList: {
    flex: 1,
  },
  emptyHistory: {
    alignItems: 'center',
    gap: 8,
    paddingTop: 20,
  },
  emptyHistoryText: {
    fontSize: 12,
    fontFamily: Fonts.calSans,
    textAlign: 'center',
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    paddingVertical: 9,
    borderRadius: 10,
    marginBottom: 2,
  },
  historyItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    marginRight: 6,
  },
  historyTitle: {
    fontSize: 13,
    fontFamily: Fonts.calSans,
    marginBottom: 2,
  },
  historyTime: {
    fontSize: 11,
    fontFamily: Fonts.calSans,
  },
  deleteHistBtn: {
    padding: 4,
  },
  personalizationBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    paddingTop: 14,
    paddingBottom: 16,
    marginTop: 4,
  },
  personalizationLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  avatarCircle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  personalizeName: {
    fontSize: 13,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  personalizeRegion: {
    fontSize: 11,
    fontFamily: Fonts.calSans,
    marginTop: 1,
  },

  // ── Chat ─────────────────────────────────────────────────────────
  chatMain: { flex: 1 },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 11,
    borderBottomWidth: 1,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 11,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerInfo: { gap: 1 },
  headerTitle: { fontSize: 17, fontWeight: '700', fontFamily: Fonts.calSans },
  headerSub: { fontSize: 11, fontFamily: Fonts.calSans },
  onlineBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  onlineDot: { width: 7, height: 7, borderRadius: 3.5 },
  onlineText: { fontSize: 12, fontWeight: '600', fontFamily: Fonts.calSans },

  // ── Messages ─────────────────────────────────────────────────────
  messagesContainer: {
    flexGrow: 1,
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    maxWidth: 640,
    alignSelf: 'center',
    width: '100%',
    paddingVertical: 20,
  },
  botCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginTop: 16,
    textAlign: 'center',
    fontFamily: Fonts.calSans,
  },
  emptyDesc: {
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
    maxWidth: 360,
    lineHeight: 22,
    fontFamily: Fonts.calSans,
  },
  suggestionsGrid: {
    marginTop: 24,
    gap: 10,
    width: '100%',
  },
  suggestionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 13,
  },
  suggestionText: {
    fontSize: 13,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
    flex: 1,
  },
  messagesList: {
    gap: 14,
    maxWidth: 720,
    width: '100%',
    alignSelf: 'center',
  },
  messageRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  rowUser: { justifyContent: 'flex-end' },
  rowBot: { justifyContent: 'flex-start' },
  botAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  userAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  userAvatarText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: 16,
    paddingVertical: 11,
    borderRadius: 20,
  },
  bubbleUser: { borderBottomRightRadius: 4 },
  bubbleBot: { borderBottomLeftRadius: 4, borderWidth: 1 },
  bubbleText: { fontSize: 14, lineHeight: 22, fontFamily: Fonts.calSans },
  bubbleTime: { fontSize: 10, marginTop: 5, fontFamily: Fonts.calSans },
  typingRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  typingText: { fontSize: 13, fontFamily: Fonts.calSans },

  // ── Input Bar ────────────────────────────────────────────────────
  inputBar: { padding: 12, borderTopWidth: 1 },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 6,
    maxWidth: 720,
    width: '100%',
    alignSelf: 'center',
    gap: 8,
  },
  textInput: {
    flex: 1,
    fontSize: 14,
    fontFamily: Fonts.calSans,
    paddingVertical: 8,
    maxHeight: 120,
  },
  sendBtn: {
    width: 38,
    height: 38,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 2,
  },
  inputHint: {
    textAlign: 'center',
    fontSize: 10,
    marginTop: 6,
    fontFamily: Fonts.calSans,
  },

  // ── Settings Modal ───────────────────────────────────────────────
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  settingsCard: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  settingsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  settingsTitle: {
    fontSize: 18,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  settingsLabel: {
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 6,
    fontFamily: Fonts.calSans,
    marginTop: 10,
  },
  settingsInput: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 14,
    fontFamily: Fonts.calSans,
  },
  settingsHint: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 14,
    fontFamily: Fonts.calSans,
  },
  saveBtn: {
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 20,
  },
  saveBtnText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});
