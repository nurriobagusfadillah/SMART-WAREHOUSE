import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { Thermometer, Droplets, Minus, Plus } from 'lucide-react-native';
import { DetailHeader } from '@/components/DetailHeader';
import { DetailNav } from '@/components/DetailNav';
import { GebyFloatingButton } from '@/components/GebyFloatingButton';
import { useApp } from '@/hooks/use-app-context';
import { useWarehouseSensor } from '@/hooks/use-warehouse-sensor';
import { Fonts } from '@/constants/theme';

export default function ControlsScreen() {
  const { colors, warehouses, selectedWarehouseId, theme } = useApp();
  const { width } = useWindowDimensions();

  const warehouse = warehouses.find((w) => w.id === selectedWarehouseId) || warehouses[0];
  const warehouseName = warehouse ? warehouse.name : 'Gudang Utama';

  const sensor = useWarehouseSensor(warehouse?.pairingCode);

  const [temp, setTemp] = useState(28);
  const [humidity, setHumidity] = useState(70);
  const [saved, setSaved] = useState(false);

  const isWide = width >= 768;
  const isDark = theme === 'dark';

  const handleSave = async () => {
    await sensor.setThresholds(temp, humidity);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.page }]}>
      <DetailHeader title="Kontrol Gabah" subtitle={warehouseName} />

      <ScrollView contentContainerStyle={styles.container}>
        <View style={[styles.grid, isWide && styles.gridWide]}>
          {/* Temperature Threshold Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.halfWidth,
            ]}
          >
            <View style={styles.cardHeaderSmall}>
              <Thermometer size={18} color={colors.danger} />
              <Text style={[styles.cardHeaderLabel, { color: colors.cardMuted }]}>
                Ambang Suhu
              </Text>
            </View>

            <Text style={[styles.cardValue, { color: colors.cardText }]}>
              {temp}
              <Text style={[styles.cardUnit, { color: colors.cardMuted }]}>°C</Text>
            </Text>

            {/* Stepper Controls */}
            <View style={styles.stepperRow}>
              <TouchableOpacity
                onPress={() => setTemp((v) => Math.max(15, v - 1))}
                style={[styles.stepperBtn, { backgroundColor: isDark ? '#26282c' : 'rgba(255, 255, 255, 0.12)' }]}
              >
                <Minus size={20} color="#ffffff" />
              </TouchableOpacity>

              <View style={[styles.rangeVisual, isDark && { backgroundColor: '#26282c' }]}>
                <View
                  style={[
                    styles.rangeFill,
                    {
                      width: `${((temp - 15) / (40 - 15)) * 100}%`,
                      backgroundColor: colors.yellow,
                    },
                  ]}
                />
              </View>

              <TouchableOpacity
                onPress={() => setTemp((v) => Math.min(40, v + 1))}
                style={[styles.stepperBtn, { backgroundColor: isDark ? '#26282c' : 'rgba(255, 255, 255, 0.12)' }]}
              >
                <Plus size={20} color="#ffffff" />
              </TouchableOpacity>
            </View>

            <Text style={[styles.hintText, { color: colors.cardMuted }]}>
              Ambang batas: {temp}°C (Min: 15°C - Max: 40°C)
            </Text>
            {sensor.temperature !== null && (
              <Text style={[styles.hintText, { color: colors.brand, marginTop: 4 }]}>
                Suhu saat ini: {sensor.temperature.toFixed(1)}°C
              </Text>
            )}
          </View>

          {/* Humidity Threshold Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.halfWidth,
            ]}
          >
            <View style={styles.cardHeaderSmall}>
              <Droplets size={18} color={colors.success} />
              <Text style={[styles.cardHeaderLabel, { color: colors.cardMuted }]}>
                Ambang Kelembapan
              </Text>
            </View>

            <Text style={[styles.cardValue, { color: colors.cardText }]}>
              {humidity}
              <Text style={[styles.cardUnit, { color: colors.cardMuted }]}>%</Text>
            </Text>

            {/* Stepper Controls */}
            <View style={styles.stepperRow}>
              <TouchableOpacity
                onPress={() => setHumidity((v) => Math.max(30, v - 1))}
                style={[styles.stepperBtn, { backgroundColor: isDark ? '#26282c' : 'rgba(255, 255, 255, 0.12)' }]}
              >
                <Minus size={20} color="#ffffff" />
              </TouchableOpacity>

              <View style={[styles.rangeVisual, isDark && { backgroundColor: '#26282c' }]}>
                <View
                  style={[
                    styles.rangeFill,
                    {
                      width: `${((humidity - 30) / (90 - 30)) * 100}%`,
                      backgroundColor: colors.brand,
                    },
                  ]}
                />
              </View>

              <TouchableOpacity
                onPress={() => setHumidity((v) => Math.min(90, v + 1))}
                style={[styles.stepperBtn, { backgroundColor: isDark ? '#26282c' : 'rgba(255, 255, 255, 0.12)' }]}
              >
                <Plus size={20} color="#ffffff" />
              </TouchableOpacity>
            </View>

            <Text style={[styles.hintText, { color: colors.cardMuted }]}>
              Ambang batas: {humidity}% (Min: 30% - Max: 90%)
            </Text>
            {sensor.humidity !== null && (
              <Text style={[styles.hintText, { color: colors.brand, marginTop: 4 }]}>
                Kelembapan saat ini: {sensor.humidity.toFixed(0)}%
              </Text>
            )}
          </View>

          {/* Fan Max RPM Card */}
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card, borderColor: colors.line },
              isWide && styles.fullWidth,
            ]}
          >
            <View style={styles.rpmRow}>
              <View>
                <Text style={[styles.rpmTitle, { color: colors.cardMuted }]}>
                  Batas RPM Kipas
                </Text>
                <Text style={[styles.rpmDesc, { color: colors.cardMuted }]}>
                  Kecepatan maksimal otomatis
                </Text>
              </View>
              <Text style={[styles.rpmValue, { color: colors.success }]}>
                1200<Text style={[styles.rpmUnit, { color: colors.cardMuted }]}>rpm</Text>
              </Text>
            </View>
          </View>

          {/* Save Button */}
          <TouchableOpacity
            onPress={handleSave}
            disabled={!sensor.connected}
            style={[
              styles.saveButton,
              {
                backgroundColor: saved ? colors.success : sensor.connected ? colors.brand : colors.cardMuted,
              },
              isWide && styles.fullWidth,
            ]}
          >
            <Text style={styles.saveButtonText}>
              {saved
                ? 'Pengaturan Tersimpan ✓'
                : sensor.connected
                ? 'Simpan & Terapkan'
                : 'ESP32 tidak terhubung'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <GebyFloatingButton />
      <DetailNav />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    padding: 16,
    maxWidth: 880,
    width: '100%',
    alignSelf: 'center',
    paddingBottom: 90,
  },
  grid: {
    gap: 16,
  },
  gridWide: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  fullWidth: {
    width: '100%',
  },
  halfWidth: {
    width: '48.5%',
  },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
    shadowColor: '#293751',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 4,
  },
  cardHeaderSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardHeaderLabel: {
    fontSize: 13,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  cardValue: {
    fontSize: 38,
    fontWeight: '700',
    marginTop: 14,
    fontFamily: Fonts.calSans,
  },
  cardUnit: {
    fontSize: 22,
    fontWeight: '400',
  },
  stepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 20,
  },
  stepperBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rangeVisual: {
    flex: 1,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    overflow: 'hidden',
  },
  rangeFill: {
    height: '100%',
    borderRadius: 4,
  },
  hintText: {
    fontSize: 12,
    marginTop: 12,
    fontFamily: Fonts.calSans,
  },
  rpmRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rpmTitle: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: Fonts.calSans,
  },
  rpmDesc: {
    fontSize: 12,
    marginTop: 2,
    fontFamily: Fonts.calSans,
  },
  rpmValue: {
    fontSize: 26,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
  rpmUnit: {
    fontSize: 14,
    fontWeight: '400',
  },
  saveButton: {
    borderRadius: 18,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#3DB45A',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 4,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
    fontFamily: Fonts.calSans,
  },
});
