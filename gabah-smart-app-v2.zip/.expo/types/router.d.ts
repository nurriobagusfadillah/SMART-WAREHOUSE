/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/warehouses`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/warehouse/analytics`; params?: Router.UnknownInputParams; } | { pathname: `/warehouse/controls`; params?: Router.UnknownInputParams; } | { pathname: `/warehouse/dashboard`; params?: Router.UnknownInputParams; } | { pathname: `/warehouse/geby`; params?: Router.UnknownInputParams; } | { pathname: `/warehouse/insights`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/warehouses`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/warehouse/analytics`; params?: Router.UnknownOutputParams; } | { pathname: `/warehouse/controls`; params?: Router.UnknownOutputParams; } | { pathname: `/warehouse/dashboard`; params?: Router.UnknownOutputParams; } | { pathname: `/warehouse/geby`; params?: Router.UnknownOutputParams; } | { pathname: `/warehouse/insights`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/warehouses${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/warehouse/analytics${`?${string}` | `#${string}` | ''}` | `/warehouse/controls${`?${string}` | `#${string}` | ''}` | `/warehouse/dashboard${`?${string}` | `#${string}` | ''}` | `/warehouse/geby${`?${string}` | `#${string}` | ''}` | `/warehouse/insights${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString | Router.ExternalPathString | `/` | `/warehouses` | `/_sitemap` | `/warehouse/analytics` | `/warehouse/controls` | `/warehouse/dashboard` | `/warehouse/geby` | `/warehouse/insights`; params?: Router.UnknownInputParams; };
    }
  }
}
